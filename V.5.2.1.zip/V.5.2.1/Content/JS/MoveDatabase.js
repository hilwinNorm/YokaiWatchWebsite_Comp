const moves = [
  {
    move: "Batter",
    ID: 1,
    move_power: "15-33",
    Hit_amount: 3
  },
  {
    move: "Beat",
    ID: 2,
    move_power: "40-88",
    Hit_amount: 1
  },
  {
    move: "Bite",
    ID: 3,
    move_power: "15-67",
    Hit_amount: 1
  },
  {
    move: "Body Bash",
    ID: 4,
    move_power: "15-57",
    Hit_amount: 1
  },
  {
    move: "Bone Crusher",
    ID: 5,
    move_power: "100-150",
    Hit_amount: 1
  },
  {
    move: "Chomp",
    ID: 6,
    move_power: "45-99",
    Hit_amount: 1
  },
  {
    move: "Clobber",
    ID: 7,
    move_power: "75-112",
    Hit_amount: 1
  },
  {
    move: "Double Slice",
    ID: 8,
    move_power: "18-39",
    Hit_amount: 2
  },
  {
    move: "Earthsplitter",
    ID: 9,
    move_power: "95-142",
    Hit_amount: 1
  },
  {
    move: "Flatten",
    ID: 10,
    move_power: "30-66",
    Hit_amount: 1
  },
  {
    move: "Flip Kick",
    ID: 11,
    move_power: "60-90",
    Hit_amount: 1
  },
  {
    move: "Fullswing",
    ID: 12,
    move_power: "80-120",
    Hit_amount: 1
  },
  {
    move: "Guns Blazing",
    ID: 13,
    move_power: "15-33",
    Hit_amount: 3
  },
  {
    move: "Headbuster",
    ID: 14,
    move_power: "130-195",
    Hit_amount: 1
  },
  {
    move: "Headbutt",
    ID: 15,
    move_power: "55-121",
    Hit_amount: 1
  },
  {
    move: "Headsmack",
    ID: 16,
    move_power: "15-67",
    Hit_amount: 1
  },
  {
    move: "Hit",
    ID: 17,
    move_power: "10-45",
    Hit_amount: 1
  },
  {
    move: "Kaboom!",
    ID: 18,
    move_power: "50-110",
    Hit_amount: 1
  },
  {
    move: "Kick",
    ID: 19,
    move_power: "15-67",
    Hit_amount: 1
  },
  {
    move: "Lightning Slash ",
    ID: 20,
    move_power: "20-44",
    Hit_amount: 3
  },
  {
    move: "Maul",
    ID: 21,
    move_power: "80-120",
    Hit_amount: 1
  },
  {
    move: "Meteor Punch",
    ID: 22,
    move_power: "20-30",
    Hit_amount: 3
  },
  {
    move: "Nasty Kick",
    ID: 23,
    move_power: "100-150",
    Hit_amount: 1
  },
  {
    move: "Ninja Star",
    ID: 24,
    move_power: "60-90",
    Hit_amount: 1
  },
  {
    move: "One-Two Punch",
    ID: 25,
    move_power: "15-33",
    Hit_amount: 2
  },
  {
    move: "Palm Strike",
    ID: 26,
    move_power: "60-90",
    Hit_amount: 1
  },
  {
    move: "Pesky Poke",
    ID: 27,
    move_power: "15-67",
    Hit_amount: 1
  },
  {
    move: "Pesky Pokes",
    ID: 28,
    move_power: "12-26",
    Hit_amount: 3
  },
  {
    move: "Pinpoint Pierce",
    ID: 29,
    move_power: "30-66",
    Hit_amount: 1
  },
  {
    move: "Pointy Pokes",
    ID: 30,
    move_power: "12-26",
    Hit_amount: 3
  },
  {
    move: "Power Punch",
    ID: 31,
    move_power: "50-110",
    Hit_amount: 1
  },
  {
    move: "Practiced Punch",
    ID: 32,
    move_power: "90-135",
    Hit_amount: 1
  },
  {
    move: "Punch",
    ID: 33,
    move_power: "15-67",
    Hit_amount: 1
  },
  {
    move: "Rocket Punch",
    ID: 34,
    move_power: "100-150",
    Hit_amount: 1
  },
  {
    move: "Sharp Claws",
    ID: 35,
    move_power: "10-45",
    Hit_amount: 2
  },
  {
    move: "Shoot",
    ID: 36,
    move_power: "10-45",
    Hit_amount: 1
  },
  {
    move: "Slap",
    ID: 37,
    move_power: "10-45",
    Hit_amount: 1
  },
  {
    move: "Slurp",
    ID: 38,
    move_power: "50-110",
    Hit_amount: 1
  },
  {
    move: "Smackdown",
    ID: 39,
    move_power: "20-44",
    Hit_amount: 2
  },
  {
    move: "Spray Gun",
    ID: 40,
    move_power: "100-150",
    Hit_amount: 1
  },
  {
    move: "Squish",
    ID: 41,
    move_power: "10-45",
    Hit_amount: 1
  },
  {
    move: "Stab Storm",
    ID: 42,
    move_power: "10-22",
    Hit_amount: 5
  },
  {
    move: "Steamroll",
    ID: 43,
    move_power: "60-90",
    Hit_amount: 1
  },
  {
    move: "Stepping Slice",
    ID: 44,
    move_power: "15-67",
    Hit_amount: 1
  },
  {
    move: "Tackle",
    ID: 45,
    move_power: "60-90",
    Hit_amount: 1
  },
  {
    move: "Tail Slap",
    ID: 46,
    move_power: "100-150",
    Hit_amount: 1
  },
  {
    move: "Ventilator",
    ID: 47,
    move_power: "50-110",
    Hit_amount: 1
  },
  {
	move: "Bowshot",
	ID: 48,
	move_power: "50-110",
	Hit_amount: 1
  }
]
var GivenStats = localStorage.getItem('_move_data');

var SavingStats = JSON.stringify(moves[GivenStats-1]);
SavingStats = btoa(SavingStats)
localStorage.setItem("_trans_move_data", SavingStats);

function GetMoveID(){ // Damage Calc Function
	var GivenStats = localStorage.getItem('_move_yokai_attacker_data');
	var SavingStats = JSON.stringify(moves[GivenStats-1]);
	SavingStats = btoa(SavingStats)
	localStorage.setItem("_trans_attacker_yokai_move_data", SavingStats);
	getAttack()
}

if (typeof Defender !== "undefined"){
	let Attacker = document.getElementById("yokai_select2")
	const CalcButton = document.getElementById("calcButton")
	let AttackType = document.getElementById("AttackType")
	Defender.addEventListener("change", function(event){
		if (AttackType.value == "1"){
			if (localStorage.hasOwnProperty('_attack_yokai_move_data')) {
				var GivenStats = localStorage.getItem('_attack_yokai_move_data');
				console.log(GivenStats)
				var SavingStats = JSON.stringify(moves[GivenStats-1]);
				SavingStats = btoa(SavingStats)
				localStorage.setItem("_trans_attack_yokai_move_data", SavingStats);
}
			
		}
		
	});
}