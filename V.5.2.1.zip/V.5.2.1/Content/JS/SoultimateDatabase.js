// Target: 0 - Self; 1 - allies; 2 - enemies

// InsType: 
// 0 - No Effect; 1 - STR UP; 2 - STR DOWN; 3 - SPR UP; 4 - SPR DOWN; 5 - DEF UP; 6 - DEF DOWN; 7 - SPD UP; 8 - SPD DOWN; 9 - ALL UP; 10 - ALL DOWN;
// 11 - regen; 12 - poison; 13 - stop acting; 14 - confuse; 15 - money throw;
// 16 - Targeting; 17 - Shadow; 18 - Super Regen

const soultimates = [
{holder: 'Pandle', ID: 1, soultimate_name: 'Pointy Toothpick', power: '18x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pokes his foes with his beloved toothpick', target: [], amount: []},

{holder: 'Undy', ID: 2, soultimate_name: 'Toothpick Rainfall', power: '20x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pokes his foes very hard with his beloved toothpick', target: [], amount: []},

{holder: 'Tanbo', ID: 3, soultimate_name: 'Gutsy Cut', power: '155', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cuts into a single foe with confidence and for high damage', target: [], amount: []},

{holder: 'Cutta-nah', ID: 4, soultimate_name: 'Halfhearted Chop', power: '20x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slices his opponents while lolling around', target: [], amount: []},

{holder: 'Cutta-nah-nah', ID: 5, soultimate_name: 'Resigned Rush', power: '20x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Rushes into battle and spins around while slicing up foes.', target: [], amount: []},

{holder: 'Slacka-slash', ID: 6, soultimate_name: 'Phantom Smash', power: '155', element: 'None', InsType: [], SoultInsLevel: [], description: 'Chops an enemy with his hair. Likely to be either critical or a miss.', target: [], amount: []},

{holder: 'Brushido', ID: 7, soultimate_name: 'Cleaning Circle', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Uses his trusty brush to scrub his allies clean.', target: [], amount: []},

{holder: 'Washogun', ID: 8, soultimate_name: 'Spray Care', power: '70', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cleanses allies with his spray gun, restoring HP.', target: [], amount: []},

{holder: 'Lie-in', ID: 9, soultimate_name: "Paws 'n' Claws", power: '16x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Serves up a serious beating to his foes with his bare hands.', target: [], amount: []},

{holder: 'Lie-in Heart', ID: 10, soultimate_name: 'Lion Blade', power: '28x8', element: 'None', InsType: [], SoultInsLevel: [], description: 'Waits for the perfect moment before cutting foes with his sword.', target: [], amount: []},

{holder: 'Hissfit', ID: 11, soultimate_name: 'Angry Crosscut', power: '18x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'In a rage, he waves his sword around and strikes all foes.', target: [], amount: []},

{holder: 'Zerberker', ID: 12, soultimate_name: 'Zerberker Slash', power: '20x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Goes nuts with his cutters and slashes all of his opponents.', target: [], amount: []},

{holder: 'Snartle', ID: 13, soultimate_name: 'For Naughty Brats', power: '22x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Goes nuts with his cutters and slashes all of his opponents.', target: [], amount: []},

{holder: 'Mochismo', ID: 14, soultimate_name: 'Mochi Punch', power: '105', element: 'None', InsType: [], SoultInsLevel: [], description: 'Puffs up and decks an opponent with one mean punch.', target: [], amount: []},

{holder: 'Minochi', ID: 15, soultimate_name: 'Minochi Punch', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Puffs up and decks an opponent with one mean punch.', target: [], amount: []},

{holder: 'Tublappa', ID: 16, soultimate_name: 'Lickety-Lick', power: '40x3', element: 'None', InsType: [], SoultInsLevel: [], description: 'Unfurls his lengthy tongue and does damage to all foes.', target: [], amount: []},

{holder: 'Slicenrice', ID: 17, soultimate_name: 'Onigiri Slash', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Leaps into the air and delivers a sword blow to a single foe.', target: [], amount: []},

{holder: 'Flamurice', ID: 18, soultimate_name: 'Toasted Slash', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'Leaps into the air and delivers a sword blow to a single foe.', target: [], amount: []},

{holder: 'Helmsman', ID: 19, soultimate_name: 'Helmsman Helm', power: '---', element: 'None', InsType: [5], SoultInsLevel: [1], description: "Gives an order that raises allies' morale and DEF.", target: [1], amount: [1]},

{holder: 'Reuknight', ID: 20, soultimate_name: "Knight's Slash", power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'Draws a sword from his hip and strikes all his foes with one blow.', target: [], amount: []},

{holder: 'Corptain', ID: 21, soultimate_name: 'Ticket to Hades', power: '135', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cuts his enemies. Likely to be either critical or a miss.', target: [], amount: []},

{holder: 'Mudmunch', ID: 22, soultimate_name: 'Dirty Trick', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: 'Focuses all his rage to attack and sap the STR of his foes.', target: [], amount: []},

{holder: 'Sgt. Burly', ID: 23, soultimate_name: 'Victoryyyyyyyy!', power: '---', element: 'None', InsType: [9], SoultInsLevel: [1], description: "Boosts all allies' stats with a stint in his Beat Camp.", target: [1], amount: [1]},

{holder: 'Blazion', ID: 24, soultimate_name: 'Blazing Fist', power: '60', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Burns enemies with the flaming power of his fighting spirit.', target: [], amount: []},

{holder: 'Quaken', ID: 25, soultimate_name: 'Earthshaker', power: '75', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Shakes the earth and batters opponents with massive rocks.', target: [], amount: []},

{holder: 'Siro', ID: 26, soultimate_name: 'Roaring Stance', power: '---', element: 'None', InsType: [1], SoultInsLevel: [2], description: 'Massively increases the STR of allies with his fierce aura.', target: [1], amount: [1]},

{holder: 'Chansin', ID: 27, soultimate_name: 'Go for Broke', power: '---', element: 'None', InsType: [1], SoultInsLevel: [1], description: 'Boosts STR of allies by increasing their focus on the battle.', target: [1], amount: [1]},

{holder: 'Sheen', ID: 28, soultimate_name: 'Legendary Slash', power: '155', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cuts one foe with the blade of justice. High critical chance.', target: [], amount: []},

{holder: 'Snee', ID: 29, soultimate_name: 'Demonic Slash', power: '20x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Dices all opponents with his cursed blade.', target: [], amount: []},

{holder: 'Gleam', ID: 30, soultimate_name: 'Holy Slash', power: '165', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slices a single enemy with his sacred sword. High critical chance.', target: [], amount: []},

{holder: 'Benkei', ID: 31, soultimate_name: '999 Blades', power: '17x9', element: 'None', InsType: [], SoultInsLevel: [], description: 'Unleases 999 blades and attacks all foes.', target: [], amount: []},

{holder: 'B3-NK1', ID: 32, soultimate_name: 'B3-NK1 GUN', power: '20x9', element: 'None', InsType: [], SoultInsLevel: [], description: 'Rapidly fires blades. Likely to be either critical or a miss.', target: [], amount: []},

{holder: 'Sushiyama', ID: 33, soultimate_name: 'Sushiyama Strike', power: '210', element: 'None', InsType: [], SoultInsLevel: [], description: 'Smashes his pole onto a foe. High critical and miss chances.', target: [], amount: []},

{holder: 'Kapunki', ID: 34, soultimate_name: 'Boastful Bomber', power: '260', element: 'None', InsType: [], SoultInsLevel: [], description: 'Boldly bashes a foe with his pole. High critical/miss chance.', target: [], amount: []},

{holder: 'Beetler', ID: 35, soultimate_name: 'Big Pincers', power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pinches a foe with..well, his pincers.', target: [], amount: []},

{holder: 'Beetall', ID: 36, soultimate_name: 'Infernal Pincers', power: '195', element: 'None', InsType: [], SoultInsLevel: [], description: 'Crushes an opponent with the huge pincers atop his head.', target: [], amount: []},

{holder: 'Cruncha', ID: 37, soultimate_name: 'The Guillotine', power: '210', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cuts an enemy with the massive pincers on his head.', target: [], amount: []},

{holder: 'Demuncher', ID: 38, soultimate_name: 'Open Wide', power: '195', element: 'None', InsType: [], SoultInsLevel: [], description: 'Opens his massive mouth and chomps on a single foe.', target: [], amount: []},

{holder: 'Devourer', ID: 39, soultimate_name: 'Ill Appetite', power: '205', element: 'None', InsType: [], SoultInsLevel: [], description: 'Opens his massive mouth and chomps on a single foe.', target: [], amount: []},

{holder: 'Brokenbrella', ID: 40, soultimate_name: 'North Wind', power: '80', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Whips up a wind that turns him inside out and strikes all foes.', target: [], amount: []},

{holder: 'Pittapatt', ID: 41, soultimate_name: 'Sole Quaker', power: '75', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Uses power built up on his epic walks to strike every foe.', target: [], amount: []},

{holder: 'Snotsolong', ID: 42, soultimate_name: 'Stretchy Slap', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps an opponent with his snot. May cancel Soultimate Moves!', target: [], amount: []},

{holder: 'Duchoo', ID: 43, soultimate_name: 'Sneezy Spike', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps an opponent with his snot. May cancel Soultimate Moves!', target: [], amount: []},

{holder: "D'wanna", ID: 44, soultimate_name: 'Croaking Prayer', power: '30', element: 'None', InsType: [], SoultInsLevel: [], description: 'Hinders foes with chanted curse.', target: [2], amount: [3]},

{holder: "N'more", ID: 45, soultimate_name: 'Yawnehameha', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: 'Hinders foes with a rolling wave of curses.', target: [2], amount: [3]},

{holder: "Q'wit", ID: 46, soultimate_name: 'Yawnehameha X', power: '130', element: 'None', InsType: [6], SoultInsLevel: [2], description: "Drops a foe's DEF with a very strong wave of rolling curses.", target: [2, 2], amount: [3, 1]},

{holder: 'Wazzat', ID: 47, soultimate_name: 'Wuwuzzat?', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Undoes good effects on foes by eating up their memories.', target: [], amount: []},

{holder: 'Houzzat', ID: 48, soultimate_name: 'Forget about It', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Sucks foes into his misterious maw and causes confusion.', target: [2], amount: [1]},

{holder: 'Dummkap', ID: 49, soultimate_name: 'Ignorance Is Bliss', power: '---', element: 'None', InsType: [7], SoultInsLevel: [1], description: "Unleashes an ally's heart and significantly boosts SPD.", target: [1], amount: [1]},

{holder: 'Faysoff', ID: 50, soultimate_name: 'Blank Face', power: '65', element: 'None', InsType: [], SoultInsLevel: [], description: 'Calls spirits with no elemental afflication to damage all foes.', target: [], amount: []},

{holder: 'Lafalotta', ID: 51, soultimate_name: 'Mwabsorption', power: '50', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Absorbs HP from all foes and divides it among her allies.', target: [], amount: []},

{holder: 'Blips', ID: 52, soultimate_name: 'Blue Kiss', power: '50', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Absorbs HP from all foes and divides it among her allies.', target: [], amount: []},

{holder: 'Tattletell', ID: 53, soultimate_name: 'Loving Slap', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slabs a foe...with love. May cancel enemy Soultimate Moves.', target: [], amount: []},

{holder: 'Tattlecast', ID: 54, soultimate_name: 'Max Volume 11!', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: "Tosses speakers and slaps. May cancel foe's Soultimate Moves.", target: [], amount: []},

{holder: 'Skranny', ID: 55, soultimate_name: 'Skeleton Smack', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'A bony-handed slap that can cancel enemy Soultimate Moves.', target: [], amount: []},

{holder: 'Cupistol', ID: 56, soultimate_name: 'Kiss of Life', power: '50', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores HP of allies by blowing a very handsome kiss!', target: [], amount: []},

{holder: 'Casanuva', ID: 57, soultimate_name: 'Heavenly Heart', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores Hp of allies with his extremely handsome aura!', target: [], amount: []},

{holder: 'Casanono', ID: 58, soultimate_name: 'Fiery Longing', power: '130', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Uses his bitterness from being unpopular to fry all his foes.', target: [], amount: []},

{holder: 'So-Sorree', ID: 59, soultimate_name: 'My Bad', power: '40', element: 'None', InsType: [], SoultInsLevel: [], description: 'Apologizes profusely as he purifies all allies and boosts HP.', target: [], amount: []},

{holder: 'Bowminos', ID: 60, soultimate_name: 'Endless Apology', power: '150', element: 'None', InsType: [], SoultInsLevel: [], description: 'Crushes an enemy with the force of apology. Enemies are hindered.', target: [2], amount: [1]},

{holder: 'Smogling', ID: 61, soultimate_name: 'Cloud Control', power: '60', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Calls up a lovable little storm that damages all foes.', target: [], amount: []},

{holder: 'Smogmella', ID: 62, soultimate_name: 'Upward Tornado', power: '220', element: 'Wind', InsType: [], SoultInsLevel: [], description: "Calls a tornado strong enough to mess up the enemy's clothes.", target: [], amount: []},

{holder: 'Signibble', ID: 63, soultimate_name: 'Signal Shock', power: '55', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Releases his stored electric waves onto his foes all at once.', target: [], amount: []},

{holder: 'Signiton', ID: 64, soultimate_name: "Ton o' Thunder", power: '120', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Beats his stomach to call lightning down onto his opponents.', target: [], amount: []},

{holder: 'Statiking', ID: 65, soultimate_name: 'Giga Turbocharge', power: '190', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Absorbs HP from all foes and divides it among his allies.', target: [], amount: []},

{holder: 'Master Oden', ID: 66, soultimate_name: 'Stirring Broth', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Revives a single ally with a bowl of hot, soothing broth.', target: [], amount: []},

{holder: 'Failian', ID: 67, soultimate_name: 'Lies-er Beam', power: '95', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Blasts a foe with an ice beam he says is from outer space.', target: [], amount: []},

{holder: 'Apelican', ID: 68, soultimate_name: 'Yes We Pelican! ', power: '---', element: 'None', InsType: [9], SoultInsLevel: [1], description: "Leads a rousing line dance that boosts all of his allies' stats.", target: [1], amount: [1]},

{holder: 'Mirapo', ID: 69, soultimate_name: 'Mirror to Mirror', power: 'may vary', element: 'None', InsType: [], SoultInsLevel: [], description: 'Calls forth a random spirit from the mirror world to attack.', target: [], amount: []},

{holder: 'Miradox', ID: 70, soultimate_name: 'Mirror Mirror', power: 'may vary', element: 'None', InsType: [], SoultInsLevel: [], description: 'Calls forth a random spirit from the mirror world to attack.', target: [], amount: []},

{holder: 'Mircle', ID: 71, soultimate_name: 'Dark World', power: 'may vary', element: 'None', InsType: [], SoultInsLevel: [], description: 'Calls forth a random spirit from the mirror world to attack.', target: [], amount: []},

{holder: 'Illoo', ID: 72, soultimate_name: 'Spirit Illusion', power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: "Summons will-o'-the-wisps to damage his enemies.", target: [], amount: []},

{holder: 'Elloo', ID: 73, soultimate_name: 'Spirit Daze', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: "Summons will-o'-the-wisps to damage his enemies.", target: [], amount: []},

{holder: 'Alloo', ID: 74, soultimate_name: 'Wandering World', power: '80', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Curses his enemies with strong magic. May confuse them as well.', target: [2], amount: [3]},

{holder: 'Espy', ID: 75, soultimate_name: 'Thrid Eye', power: '55', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Absorbs HP from all foes and divides it among her allies.', target: [], amount: []},

{holder: 'Infour', ID: 76, soultimate_name: 'Foursight', power: '65', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Absorbs HP from all foes and divides it among her allies.', target: [], amount: []},

{holder: 'Verygoodsir', ID: 77, soultimate_name: 'Bon Appétit', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Top-class butler skills serve to heal all allies.', target: [], amount: []},

{holder: 'Tengu', ID: 78, soultimate_name: 'Typhoon Fan', power: '180', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Uses his fan to create a whirlwind that hits all of his enemies.', target: [], amount: []},

{holder: 'Flengu', ID: 79, soultimate_name: 'Blazing Typhoon', power: '200', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Uses his fan to create a typhoon that blasts all of his enemies.', target: [], amount: []},

{holder: 'Kyubi', ID: 80, soultimate_name: 'Inferno', power: '250', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Creates a massive fireball and burns enemies to ashes.', target: [], amount: []},

{holder: 'Frostail', ID: 81, soultimate_name: 'Arctic Abyss', power: '250', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Freeezes his foes with his powerful, icy spirit.', target: [], amount: []},

{holder: 'Chymera', ID: 82, soultimate_name: 'Shock Tactic', power: '185', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Summons a lighting strike, doin great damage to one foe.', target: [], amount: []},

{holder: 'Kingmera', ID: 83, soultimate_name: 'Thunderstruck', power: '190', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Summons a lighting strike, doin great damage to one foe.', target: [], amount: []},

{holder: 'Terrorpotta', ID: 84, soultimate_name: 'Cracked Pot', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Causes confusion in foes by teetering on the brink of tripping.', target: [2], amount: [3]},

{holder: 'Dulluma', ID: 85, soultimate_name: 'Headbutt HEY -O!', power: '60', element: 'None', InsType: [], SoultInsLevel: [], description: 'Leaps high into the air and delivers a powerful headbutt.', target: [], amount: []},

{holder: 'Darumacho', ID: 86, soultimate_name: 'Burning Buster', power: '170', element: 'None', InsType: [], SoultInsLevel: [], description: 'Jumps and charges a foe but will hurt himself with the effort.', target: [], amount: []},

{holder: 'Goruma', ID: 87, soultimate_name: 'Gorilla Straight', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: 'Unleashes a straight punch with all the strength of a gorilla.', target: [], amount: []},

{holder: 'Wotchagot', ID: 88, soultimate_name: 'Bowl Buster', power: '60', element: 'None', InsType: [], SoultInsLevel: [], description: 'Strikes a foe in envy and ends up hurting himself in the process.', target: [], amount: []},

{holder: 'Pride Shrimp', ID: 89, soultimate_name: 'Prawn Punch', power: '165', element: 'None', InsType: [], SoultInsLevel: [], description: 'Dramatically strikes a foe with a perfect cooked prawn.', target: [], amount: []},

{holder: 'No-Go Kart', ID: 90, soultimate_name: "You've Lost Me", power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'His bizarre sense of direction serves to confuse the enemy.', target: [2], amount: [3]},

{holder: 'Mistank', ID: 91, soultimate_name: "Tabk 'n' Spank", power: '170', element: 'None', InsType: [], SoultInsLevel: [], description: 'Unleashes a massive cannon blast, hitting a single foe.', target: [], amount: []},

{holder: 'Noway', ID: 92, soultimate_name: 'No Way Through', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 1], description: 'A defensive posture that boosts DEF and draws enemy attacks', target: [0, 0], amount: [1, 1]},

{holder: 'Impass', ID: 93, soultimate_name: 'Insurmountable', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'A defensive posture that  strongly boosts DEF and draws  enemy attacks', target: [0, 1], amount: [1, 1]},

{holder: 'Walldin', ID: 94, soultimate_name: 'Stonewall Drop', power: '180', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Drops a stone wall from his former castle onto his foes.', target: [], amount: []},

{holder: 'Roughraff', ID: 95, soultimate_name: 'Stare Down', power: '30', element: 'None', InsType: [8], SoultInsLevel: [], description: 'Glares at his foes and lowers their SPD.', target: [2, 2], amount: [3, 1]},

{holder: 'Badude', ID: 96, soultimate_name: 'Gangster Glare', power: '100', element: 'None', InsType: [8], SoultInsLevel: [2], description: "Glares at enemies until they're self-conscious. Lowers SPD.", target: [2, 2], amount: [3, 1]},

{holder: 'Bruff', ID: 97, soultimate_name: 'Brutal Butt Bat', power: '260', element: 'None', InsType: [], SoultInsLevel: [], description: 'Crunches his foes with his nail bat. Likely to be either critical or a miss.', target: [], amount: []},

{holder: 'Armsman', ID: 98, soultimate_name: 'Lock of Steel', power: '---', element: 'None', InsType: [5], SoultInsLevel: [1], description: "Gives an order that raises allies' morale and DEF.", target: [1], amount: [1]},

{holder: 'Mimikin', ID: 99, soultimate_name: 'Imitate Guardian ', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Ups his DEF by mimicking a deity, drawing enemy attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Blowkade', ID: 100, soultimate_name: 'Barricade Block', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 1], description: 'Raises DEF and draws enemy attacks. Quite the effective blockade.', target: [0, 1], amount: [1, 1]},

{holder: 'Ledballoon', ID: 101, soultimate_name: 'Iron Cloutain', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps an enemy. Can cancel enemy Soultimate Moves.', target: [], amount: []},

{holder: 'Fidgephant', ID: 102, soultimate_name: 'Fidgeting Smack', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps an opponent with his nose. May cancel Soultimate Moves.', target: [], amount: []},

{holder: 'Touphant', ID: 103, soultimate_name: 'Trembling Smack', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps an opponent with his nose. May cancel Soultimate Moves.', target: [], amount: []},

{holder: 'Enduriphant', ID: 104, soultimate_name: 'Patience Wall', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Turns himself into a wall, hugely inccreasing DEF.', target: [0, 1], amount: [1, 1]},

{holder: 'Zappary', ID: 105, soultimate_name: 'Zattack', power: '65', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Pierces a single foe with an impressive bold of lightning.', target: [], amount: []},

{holder: 'Frazzel', ID: 106, soultimate_name: 'Divine Strike', power: '180', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Releases the electric power he has absorbed and strikes all foes.', target: [], amount: []},

{holder: 'Swelton', ID: 107, soultimate_name: 'Sweaty Wall', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Ups DEF with a sweaty stance and draws enemy attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Mad Mountain', ID: 108, soultimate_name: 'Ultra Sumo Stomp', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 1], description: 'Makes a defensive stomp. Boosts DEF and draws enemy attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Lava Lord', ID: 109, soultimate_name: 'Midnight Stomp', power: '---', element: 'None', InsType: [16, 5, 9], SoultInsLevel: [1, 3], description: 'Makes a defensive stomp. Greatly boosts DEF. Draws attacks.', target: [0, 1], amount: [1, 3]},

{holder: 'Castelius III', ID: 110, soultimate_name: 'Self-Destruct', power: '220', element: 'None', InsType: [], SoultInsLevel: [], description: 'Explosion that will deal damage to enemies and allies alike.', target: [], amount: []},

{holder: 'Castelius II', ID: 111, soultimate_name: 'Refined Guard', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'A strong defensive pose, Greatly boosts DEF. Draws attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Castelius I', ID: 112, soultimate_name: 'Glorious Buh-Bye', power: '250', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Explosion that will deal damage to enemies and allies alike.', target: [0, 1], amount: [1, 1]},

{holder: 'Castelius Max', ID: 113, soultimate_name: 'Platinum Guard', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'A strong defensive pose with a strong DEF boost. Draws attacks.', target: [], amount: []},

{holder: 'Rhinoggin', ID: 114, soultimate_name: 'Super Horn Crash', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: 'Crashes into an enemy with his prized horn and deals big damage.', target: [], amount: []},

{holder: 'Rhinormous', ID: 115, soultimate_name: 'Horn Breaker', power: '190', element: 'None', InsType: [], SoultInsLevel: [], description: 'Smashes into an enemy like a dump truck with a horn!', target: [], amount: []},

{holder: 'Hornaplenty', ID: 116, soultimate_name: 'Horn Explosion', power: '210', element: 'None', InsType: [], SoultInsLevel: [], description: 'Smashes into an enemy like a dump truck with a horn!', target: [], amount: []},

{holder: 'Robonyan', ID: 117, soultimate_name: 'Guard Meowde', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Increases DEF and draws enemy attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Goldenyan', ID: 118, soultimate_name: 'Gold Thundpurr', power: '---', element: 'None', InsType: [9], SoultInsLevel: [2], description: 'Increases stats of allies with mystic, golden powers.', target: [1], amount: [1]},

{holder: 'Dromp', ID: 119, soultimate_name: 'Total Collapse', power: '300', element: 'None', InsType: [], SoultInsLevel: [], description: 'Explosion that will deal damage to enemies and allies alike.', target: [], amount: []},

{holder: 'Swosh', ID: 120, soultimate_name: 'Tidal Guard', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Braces himself and raises DEF for the attacks he will draw.', target: [0, 1], amount: [1, 1]},

{holder: 'Toadal Dude', ID: 121, soultimate_name: 'Warts and All', power: '46x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all foes with a blast of plent-up toad power.', target: [], amount: []},

{holder: 'Uber Geeko', ID: 122, soultimate_name: 'Geck Out', power: '42x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all foes with a blast of plent-up toad power.', target: [], amount: []},

{holder: 'Leggly', ID: 123, soultimate_name: 'Shake a Leg', power: '---', element: 'None', InsType: [7], SoultInsLevel: [1], description: 'Boost morale, giving her allies a burst of SPD.', target: [1], amount: [1]},

{holder: 'Dazzabel', ID: 124, soultimate_name: '⭐️Stylish Stab', power: '17x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Repeatedly slabs her opponents wit her stylish umbrella.', target: [], amount: []},

{holder: 'Rattelle', ID: 125, soultimate_name: '⭐️Prism Parasol', power: '22x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pokes all foes with her sassy umbrella.', target: [], amount: []},

{holder: 'Skelebella', ID: 126, soultimate_name: '⭐️Radiant Rain', power: '160', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Damages opponents by calling down rain to match her umbrella.', target: [], amount: []},

{holder: 'Cadin', ID: 127, soultimate_name: 'Cicada Cut', power: '18x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Nervously slices all of his foes.', target: [], amount: []},

{holder: 'Cadable', ID: 128, soultimate_name: 'Shadow Speed', power: '---', element: 'None', InsType: [7], SoultInsLevel: [2], description: "Cicada ninjutsu's ultimate move! This boosts SPD of allies.", target: [1], amount: [1]},

{holder: 'Singcada', ID: 129, soultimate_name: 'Wind Run', power: '---', element: 'None', InsType: [7], SoultInsLevel: [2], description: "Cicada ninjutsu's ultimate technique! Boosts SPD of allies.", target: [1], amount: [1]},

{holder: 'Pupsicle', ID: 130, soultimate_name: 'Icicle Crack', power: '55', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Drops a number of sharp icicles on his opponents.', target: [], amount: []},

{holder: 'Chilhuahua', ID: 131, soultimate_name: 'Subzero', power: '125', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Crushes his foes with an icy blast.', target: [], amount: []},

{holder: 'Swelterrier', ID: 132, soultimate_name: 'Heat Wave', power: '140', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Overwhelms his foes with a stifling heat.', target: [], amount: []},

{holder: 'Jumbelina', ID: 133, soultimate_name: 'Change Face', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Rearranges her facial features at top speed to confuse foes.', target: [2], amount: [1]},

{holder: 'Boyclops', ID: 134, soultimate_name: 'Eyelusion', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Stares down the enemy showing discomfort in their ranks.', target: [2], amount: [1]},

{holder: 'Jibanyan', ID: 135, soultimate_name: 'Paws of Fury', power: '20x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Punches all opponents with paws trained on moving vehicles.', target: [], amount: []},

{holder: 'Thornyan', ID: 136, soultimate_name: 'Thorny Thwacks', power: '23x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Grows spikes on his paws and punches all opponents.', target: [], amount: []},

{holder: 'Baddinyan', ID: 137, soultimate_name: 'Nyice ta Beatcha', power: '130', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Damages and confuses his enemies with a wave of evil.', target: [2], amount: [1]},

{holder: 'Buchinyan', ID: 138, soultimate_name: 'Flurry of Furry', power: '13x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'A new level of Paws of Fury that deals damage to all foes.', target: [], amount: []},

{holder: 'Walkappa', ID: 139, soultimate_name: 'Mega Waterfall', power: '80', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Summons a huge waterfall directly above his enemies.', target: [], amount: []},

{holder: 'Appak', ID: 140, soultimate_name: 'Torrent Slash', power: '130', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Puts all his spirit into his water blade to cut his enemies.', target: [], amount: []},

{holder: 'Supyo', ID: 141, soultimate_name: 'Bodacious Slash', power: '135', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Puts all his spirit into his water blade to cut his enemies.', target: [], amount: []},

{holder: 'Komasan', ID: 142, soultimate_name: 'Spirit Dance', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: "Summons will-o'-the-wisps to damage his enemies.", target: [], amount: []},

{holder: 'Komane', ID: 143, soultimate_name: 'Spirit Burst', power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: "Will-o'-wisps fly from his body to burn his foes.", target: [], amount: []},

{holder: 'Komajiro', ID: 144, soultimate_name: 'Wild Zaps', power: '85', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Calls down lightning upon his opponents.', target: [], amount: []},

{holder: 'Komiger', ID: 145, soultimate_name: 'Crazy Lightning', power: '120', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Calls down strong lightning bolts upon his unfortunate enemies.', target: [], amount: []},

{holder: 'Baku', ID: 146, soultimate_name: 'Sleepy Smoke', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Sprays smoke from his nose and puts his foes to sleep.', target: [2, 2], amount: [3, 3]},

{holder: 'Bakulia', ID: 147, soultimate_name: 'Sleepy Gas', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Emits sleeping gas from her nostrils, flooring all foes.', target: [2], amount: [3]},

{holder: 'Whapir', ID: 148, soultimate_name: 'Daydream', power: '---', element: 'None', InsType: [13], SoultInsLevel: [1], description: 'Heals the heart and HP of allies with happy dreams.', target: [], amount: [3]},

{holder: 'Drizzelda', ID: 149, soultimate_name: 'Drenched', power: '80', element: 'Water', InsType: [], SoultInsLevel: [], description: 'A deluge of deeply depressing rain does damage to all foes.', target: [], amount: []},

{holder: 'Nekidspeed', ID: 150, soultimate_name: 'Flying Start', power: '---', element: 'None', InsType: [7], SoultInsLevel: [3], description: 'Comes flying out of the blocks with a huge SPD boost.', target: [1], amount: [1]},

{holder: 'Shmoopie', ID: 151, soultimate_name: 'Heartstring Tug', power: '90', element: 'None', InsType: [], SoultInsLevel: [], description: "He's oh-so cute! The hearts of his allies skip a beat and recover HP.", target: [], amount: []},

{holder: 'Pinkipoo', ID: 152, soultimate_name: 'Heartmelt Love', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: "He's so adorable! The hearts of his allies skip a beat and recover HP.", target: [], amount: []},

{holder: 'Pookivil', ID: 153, soultimate_name: 'Twisted Love', power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: 'Heals the hearts of his allies (and restores HP) when he acts cute.', target: [], amount: []},

{holder: 'Harry Barry', ID: 154, soultimate_name: 'Bear Knuckle', power: '170', element: 'None', InsType: [], SoultInsLevel: [], description: 'Bolstered by hearty Harrisville vegetables, he hits a single foe.', target: [], amount: []},

{holder: 'Frostina', ID: 155, soultimate_name: 'Snow Sherbet', power: '65', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Bombards opponents with a barrage of freezing icicles.', target: [], amount: []},

{holder: 'Blizzaria', ID: 156, soultimate_name: 'Shiny Snowdrifts', power: '180', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Blasts her opponents with a sparkling ice formation.', target: [], amount: []},

{holder: 'Damona', ID: 157, soultimate_name: '⭐️Shiny Chaos', power: '140', element: 'None', InsType: [10], SoultInsLevel: [2], description: 'Damags her foes and lowers their stats with a dark power.', target: [2, 2], amount: [3, 1]},

{holder: 'Faux Kappa', ID: 158, soultimate_name: 'Mega Wave', power: '170', element: 'Water', InsType: [], SoultInsLevel: [], description: "Harnesses the power of a river's flow to do damage to a foe.", target: [], amount: []},

{holder: 'Tigappa', ID: 159, soultimate_name: 'Raging River', power: '200', element: 'Water', InsType: [], SoultInsLevel: [], description: "Harnesses the power of a river's flow to do damage to a foe.", target: [], amount: []},

{holder: 'Master Nyada', ID: 160, soultimate_name: 'The Hose', power: '210', element: 'None', InsType: [], SoultInsLevel: [], description: 'Infinite Hose energy flows his palms, damaging all enemies.', target: [], amount: []},

{holder: 'Wantston', ID: 161, soultimate_name: 'Envious Hand', power: '45', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Grows a hand from his mouth and gives enemy HP to his allies.', target: [], amount: []},

{holder: 'Grubsnitch', ID: 162, soultimate_name: 'Grub Stealer', power: '50', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Grows a hand from his mouth and gives enemy HP to his allies.', target: [], amount: []},

{holder: 'Wiglin', ID: 163, soultimate_name: 'Wiggling Wave', power: '---', element: 'None', InsType: [5], SoultInsLevel: [2], description: 'Raises the cheear and DEF of all allies with a catchy tune.', target: [1], amount: [1]},

{holder: 'Kelpacabana', ID: 164, soultimate_name: 'Seaweed Carnival', power: '---', element: 'None', InsType: [13], SoultInsLevel: [2], description: "An elaborate dance steadly restores all allies' HP.", target: [], amount: [3]},

{holder: 'Steppa', ID: 165, soultimate_name: 'Mambo Madness', power: '---', element: 'None', InsType: [7], SoultInsLevel: [2], description: 'Dances a mambo to get his allies moving faster.', target: [1], amount: [1]},

{holder: 'Rhyth', ID: 166, soultimate_name: 'Seaweed Samba', power: '---', element: 'None', InsType: [13], SoultInsLevel: [1], description: 'Dances a samba that gradually restores HP of her allies.', target: [], amount: [3]},

{holder: 'Hungramps', ID: 167, soultimate_name: 'Hungry Impact', power: '50', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores HP for allies with a wealth of heavenly rice balls.', target: [], amount: []},

{holder: 'Hungorge', ID: 168, soultimate_name: 'Gleeful Gluttony', power: '90', element: 'None', InsType: [], SoultInsLevel: [], description: 'Heals allies with rice balls summoned by the power of gluttony.', target: [], amount: []},

{holder: 'Grainpa', ID: 169, soultimate_name: 'Fresh Impact', power: '150', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores HP for allies with a wealth of fresh rice balls.', target: [], amount: []},

{holder: 'Tongus', ID: 170, soultimate_name: 'Lick of Love', power: '50', element: 'None', InsType: [], SoultInsLevel: [], description: 'All allies are licked from head to toe, and their HP is restored.', target: [], amount: []},

{holder: 'Nurse Tongus', ID: 171, soultimate_name: 'Lick of Life', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'All allies are licked from head to toe, and their HP is restored.', target: [], amount: []},

{holder: 'Sandmeh', ID: 172, soultimate_name: 'Sandslide', power: '80', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'A ton of loose sand is dumped on the enemy.', target: [], amount: []},

{holder: 'Mr. Sandmeh', ID: 173, soultimate_name: 'Sand Stormal', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'All foes are struck by the force of a steady lifestyle.', target: [], amount: []},

{holder: 'Pallysol', ID: 174, soultimate_name: 'Umbrella Gust', power: '90', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Strikes all enemies with a dry gust of wind from a traditional Yo-kai.', target: [], amount: []},

{holder: 'Scarasol', ID: 175, soultimate_name: 'Umbrellicade', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Opens his parasol to boost his DEF and draw enemy attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Lodo', ID: 176, soultimate_name: 'I Want It All!', power: '50', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Sucks in everything without thinking. Gives enemy HP to allies.', target: [], amount: []},

{holder: 'Supoor Hero', ID: 177, soultimate_name: 'Empty Pockets', power: '36x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Tosses all his coins at the enemy with great force.', target: [], amount: []},

{holder: 'Chippa', ID: 178, soultimate_name: 'Carefree Hero', power: '90', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Confuses his enemies with his strange pose and mysterious aura.', target: [2], amount: [1]},

{holder: 'Gnomey', ID: 179, soultimate_name: 'Innocent World', power: '---', element: 'None', InsType: [13, 13], SoultInsLevel: [1, 1], description: "The power of good, clean fun steadily restores allies' HP.", target: [], amount: [3, 3]},

{holder: 'High Gnomey', ID: 180, soultimate_name: 'Joyful Jig', power: '---', element: 'None', InsType: [13], SoultInsLevel: [1], description: "The healing power of dance steadily restores allies' HP.", target: [], amount: [3]},

{holder: 'Enerfly', ID: 181, soultimate_name: 'Energy Heaven', power: '60', element: 'None', InsType: [], SoultInsLevel: [], description: 'Creates an energizing breeze that restores HP for allies.', target: [], amount: []},

{holder: 'Enefly', ID: 182, soultimate_name: 'Enemy Aura', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Uses his evil spirit to undo all good effects on enemies.', target: [], amount: []},

{holder: 'Betterfly', ID: 183, soultimate_name: 'Bestacular', power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slams a single enemy to the ground with the force of a raging bull.', target: [], amount: []},

{holder: 'Peppillon', ID: 184, soultimate_name: 'Party Miracle', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: "Blows a gust that restores HP and raises allies' spirits!", target: [], amount: []},

{holder: 'Predictabull', ID: 185, soultimate_name: 'Soothing Fortune', power: '70', element: 'None', InsType: [], SoultInsLevel: [], description: "Good fortune causes all allies' HP to recover.", target: [], amount: []},

{holder: 'Smashibull', ID: 186, soultimate_name: 'Bull Rush', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slams a single enemy to the ground with the force of a raging bull.', target: [], amount: []},

{holder: 'Don Chan', ID: 187, soultimate_name: "Rockin' Rockets", power: '100', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'The sound of drums summons fireworks to rain upon all foes.', target: [], amount: []},

{holder: "Ray O'Light", ID: 188, soultimate_name: 'Solar Flare', power: '80', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Enemies are engulfed in a fiery conflagration.', target: [], amount: []},

{holder: 'Happierre', ID: 189, soultimate_name: 'Air of Happiness', power: '---', element: 'None', InsType: [13], SoultInsLevel: [1], description: 'Gradually recovers HP of allies with his blissfull aura.', target: [], amount: [3]},

{holder: 'Reversa', ID: 190, soultimate_name: 'Fun Field', power: '---', element: 'None', InsType: [13], SoultInsLevel: [2], description: 'Steadly recovers HP of allies with her exciting aura.', target: [], amount: [3]},

{holder: 'Reversette', ID: 191, soultimate_name: 'Zany Zone', power: '---', element: 'None', InsType: [13], SoultInsLevel: [2], description: 'Steadly recovers HP of allies with her exciting aura.', target: [], amount: [3]},

{holder: "Ol' Saint Trick", ID: 192, soultimate_name: 'Pick-a-Present', power: '---', element: 'None', InsType: [9], SoultInsLevel: [1], description: 'Pulls something out of a bag ...What comes out is up to chance!', target: [1], amount: [1]},

{holder: "Ol' Fortune", ID: 193, soultimate_name: 'Get-a-Present', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'Opens a bag full of presents that restore HP of allies.', target: [], amount: []},

{holder: 'Rollen', ID: 194, soultimate_name: 'Roll of Fate', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Rolls his eyes and attacks based on the result of the dice roll.', target: [], amount: []},

{holder: 'Dubbles', ID: 195, soultimate_name: 'Hit It Big!', power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: "Attacks with the kind of damage you'd expect from rolling doubles.", target: [], amount: []},

{holder: 'Papa Bolt', ID: 196, soultimate_name: "A Father's Scorn", power: '125', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Zaps foes with the lighting of fatherly discontent. Yikes!', target: [], amount: []},

{holder: 'Uncle Infinite', ID: 197, soultimate_name: 'Table Flip', power: '250', element: 'None', InsType: [], SoultInsLevel: [], description: 'Flips a table onto foes. High chance to cancel Soultimate Moves.', target: [], amount: []},

{holder: 'Mama Aura', ID: 198, soultimate_name: "A Mother's Love", power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Steadily recovers HP for allies with her motherly warmth.', target: [], amount: []},

{holder: 'Auntie Heart', ID: 199, soultimate_name: 'Loving Auntie', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Revives and heals her allies with all the love of a favorite aunt.', target: [], amount: []},

{holder: 'Kyryn', ID: 200, soultimate_name: "Kyryn's Kry", power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Revives and heals her allies with all the love of a favorite aunt.', target: [], amount: []},

{holder: 'Unikirin', ID: 201, soultimate_name: 'Horn of Plenty', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: "A holy howl is sent to heaven, fully restoring allies' HP.", target: [], amount: []},

{holder: 'Leadoni', ID: 202, soultimate_name: 'C-mon, This Way!', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 1], description: 'Draws enemy attacks to himself while increasing his DEF.', target: [0, 1], amount: [1, 1]},

{holder: 'Mynimo', ID: 203, soultimate_name: 'Just for You', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 1], description: 'Raises the DEF of all allies. Affects all enemy attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Ake', ID: 204, soultimate_name: 'Shoulder Crunch', power: '135', element: 'None', InsType: [], SoultInsLevel: [], description: "Jumps up to hurt an enemy's shoulder but will hurt himself too...", target: [], amount: []},

{holder: 'Payn', ID: 205, soultimate_name: 'Shoulder Lock', power: '145', element: 'None', InsType: [], SoultInsLevel: [], description: "Jumps up to hurt an enemy's shoulder but will hurt himself too...", target: [], amount: []},

{holder: 'Agon', ID: 206, soultimate_name: 'Backache Buster', power: ' 180', element: 'None', InsType: [], SoultInsLevel: [], description: "Bashes a foe's hips. May cancel Soultimate Moves.", target: [], amount: []},

{holder: 'Wydeawake', ID: 207, soultimate_name: 'Worn Out', power: '---', element: 'None', InsType: [6], SoultInsLevel: [2], description: 'Too many late nights greatly weakens enemy defenses.', target: [2, 2], amount: [3, 1]},

{holder: 'Allnyta', ID: 208, soultimate_name: 'Tuckered Out', power: '---', element: 'None', InsType: [6], SoultInsLevel: [3], description: 'Too many late nights massively weakens enemy defenses.', target: [2, 2], amount: [3, 1]},

{holder: 'Herbiboy', ID: 209, soultimate_name: 'Sap', power: '---', element: 'None', InsType: [2], SoultInsLevel: [2], description: "A faintly wimpy aura greatly weakens the enemy's attack.", target: [2, 2], amount: [3, 1]},

{holder: 'Carniboy', ID: 210, soultimate_name: 'Proteam', power: '---', element: 'None', InsType: [1], SoultInsLevel: [1], description: 'An aura of vim and vigor boosts allies attacking prowess.', target: [1], amount: [1]},

{holder: 'Negatibuzz', ID: 211, soultimate_name: 'Negativity Germs', power: '20', element: 'None', InsType: [6], SoultInsLevel: [1], description: 'Spreads negativity germs that lower enemy DEF.', target: [2, 2], amount: [3, 1]},

{holder: 'Moskevil', ID: 212, soultimate_name: 'Think Evil', power: '80', element: 'None', InsType: [6], SoultInsLevel: [1], description: 'Sends evil sound waves at his enemies and lowers their DEF.', target: [2, 2], amount: [3, 1]},

{holder: 'Scritchy', ID: 213, soultimate_name: 'Itchpocalypse', power: '120', element: 'None', InsType: [2], SoultInsLevel: [2], description: 'Makes enemies itchy and lowers their STR.', target: [2, 2], amount: [3, 1]},

{holder: 'Dimmy', ID: 214, soultimate_name: 'Did You See Me?', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: "Deals a strong but dull slap. Can cancel foe's Soultimate Move.", target: [], amount: []},

{holder: 'Blandon', ID: 215, soultimate_name: 'Hazy Dance', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'Deals a strong hit. May cancel enemy Soultimate Moves.', target: [], amount: []},

{holder: 'Nul', ID: 216, soultimate_name: "Creep 'n' Cut", power: '200', element: 'None', InsType: [], SoultInsLevel: [], description: 'Hits from the shadows and may cancel enemy Soultimate Moves.', target: [], amount: []},

{holder: 'Suspicioni', ID: 217, soultimate_name: 'Suspicious Eyes', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Gives his enemies the evil eye and hinders their actions.', target: [2], amount: [3]},

{holder: 'Tantroni', ID: 218, soultimate_name: 'Temper Tantrum', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Gives his enemies the evil eye and hinders their actions.', target: [2], amount: [3]},

{holder: 'Contrarioni', ID: 219, soultimate_name: 'Contrary Gas', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Spreads gas that makes enemies contrarians, causing chaos.', target: [2], amount: [1]},

{holder: 'Hidabat', ID: 220, soultimate_name: 'Hidabat Harmony', power: '60', element: 'None', InsType: [], SoultInsLevel: [], description: 'Hinders enemies with a cursed lullaby.', target: [2], amount: [3]},

{holder: 'Abodabat', ID: 221, soultimate_name: 'Abodaballad', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Hinders enemies with a baleful ballad.', target: [2], amount: [3]},

{holder: 'Belfree', ID: 222, soultimate_name: 'Belfree Blues', power: '150', element: 'None', InsType: [], SoultInsLevel: [], description: 'Hinders enemies with some bad-luck blues.', target: [2], amount: [3]},

{holder: 'Yoink', ID: 223, soultimate_name: 'Energetic Gulp', power: '50', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Yoink helps himself to enemy HP, sharing it among his allies.', target: [], amount: []},

{holder: 'Gimme', ID: 224, soultimate_name: 'Life Looter', power: '130', element: 'Drain', InsType: [], SoultInsLevel: [], description: "Enemy HP is skillfully pilfered and shared among Gimme's allies.", target: [], amount: []},

{holder: "K'mon-K'mon", ID: 225, soultimate_name: 'Abrupt Punch', power: '80', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'An enemy is confused by an explosion of pent-up frustration.', target: [2], amount: [3]},

{holder: 'Yoodooit', ID: 226, soultimate_name: 'Borrowed Health', power: '70', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'An evil staff is used to steal enemy HP and share it with allies.', target: [], amount: []},

{holder: 'Count Zapaway', ID: 227, soultimate_name: 'Channel Changer', power: '80', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'An infared signal damages the enemy and causes confusion.', target: [2], amount: [3]},

{holder: 'Tyrat', ID: 228, soultimate_name: 'Me, Me, Me', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: "The sheer scale of Tyrat's selfishness confuses the enemy.", target: [2], amount: [3]},

{holder: 'Tengloom', ID: 229, soultimate_name: 'Gloomy Storm', power: '90', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Batters enemies with a powerful tornado.', target: [], amount: []},

{holder: 'Nird', ID: 230, soultimate_name: 'Demonic Storm', power: '100', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Buffets enemies with vicious winds from the underworld.', target: [], amount: []},

{holder: 'Snobetty', ID: 231, soultimate_name: 'How Dare You!', power: '20x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps an enemy for no good reason, stopping it from moving.', target: [2], amount: [3]},

{holder: 'Slimamander', ID: 232, soultimate_name: 'Triple Trouble', power: '25x6', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slams all enemies using his three powerful heads.', target: [], amount: []},

{holder: 'Dracunyan', ID: 233, soultimate_name: 'Big Bloodsucker', power: '150', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Sucks the HP out of one enemy and shares it with his allies.', target: [], amount: []},

{holder: 'Negasus', ID: 234, soultimate_name: 'Negasus Curse', power: '---', element: 'None', InsType: [2], SoultInsLevel: [3], description: 'Creates an evil aura that lowers STR of all enemies.', target: [2, 2], amount: [3, 1]},

{holder: 'Neighfarious', ID: 235, soultimate_name: 'Dark Horse', power: '---', element: 'None', InsType: [6], SoultInsLevel: [3], description: 'Creates an evil aura that lowers DEF of all enemies.', target: [2, 2], amount: [3, 1]},

{holder: 'Timidevil', ID: 236, soultimate_name: 'Timid Boo', power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: 'Curses his foes with a spell that gradually decreases HP.', target: [], amount: []},

{holder: 'Beelzebold', ID: 237, soultimate_name: 'Boldakazam', power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: 'Curses his foes with a spell that steadily decreases HP.', target: [], amount: []},

{holder: 'Count Cavity', ID: 238, soultimate_name: 'Bacteria Barrage', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: 'Steadily decreases enemy HP while giving them jet-black cavities.', target: [], amount: []},

{holder: 'Eyesoar', ID: 239, soultimate_name: 'Centur-Eye Stare', power: '37x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Beams of light fire from his eyes, damaging all enemies.', target: [], amount: []},

{holder: 'Eyellure', ID: 240, soultimate_name: 'Dazzling Glare', power: '43x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Beams of light fire from his eyes, damaging all enemies.', target: [], amount: []},

{holder: 'Greesel', ID: 241, soultimate_name: 'Stingy Curse', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'An ominous, villainous curse lowers the HP of all enemies.', target: [], amount: []},

{holder: 'Awevil', ID: 242, soultimate_name: 'Pitch-Black Curse', power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: 'The dark power of eternity hinders enemy actions.', target: [2], amount: [3]},

{holder: 'Wobblewok', ID: 243, soultimate_name: 'Pitch Bomber', power: '200', element: 'None', InsType: [], SoultInsLevel: [], description: 'A giant ball of darkness crashes into all foes.', target: [], amount: []},

{holder: 'Coughkoff', ID: 244, soultimate_name: 'Koff Dropper', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'His prickly nature undoes all good effects on enemies.', target: [], amount: []},

{holder: 'Hurchin', ID: 245, soultimate_name: 'Sting Bomb', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: 'Explosion that will deal damage to enemies and allies alike.', target: [], amount: []},

{holder: 'Droplette', ID: 246, soultimate_name: 'Drizzling Shower', power: '50', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Builds up moisture and dumps rain on his foes.', target: [], amount: []},

{holder: 'Drizzle', ID: 247, soultimate_name: 'Heavy Squall', power: '160', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Builds moisture and dumps a squall on his opponents.', target: [], amount: []},

{holder: 'Slush', ID: 248, soultimate_name: 'Shivering Sigh', power: '50', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Uses his frosty power to drop icicles on his enemies.', target: [], amount: []},

{holder: 'Alhail', ID: 249, soultimate_name: 'Heavenly Hail', power: '160', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Drops a hailstorm like a meteor shower down upon his foes.', target: [], amount: []},

{holder: 'Gush', ID: 250, soultimate_name: 'Nosebleed Bomb', power: '100', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Blasts his opponents with enough power to give them nosebleeds.', target: [], amount: []},

{holder: 'Peckpocket', ID: 251, soultimate_name: 'Life Snag', power: '45', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Snags HP from all opponents and divides it among his allies.', target: [], amount: []},

{holder: 'Robbinyu', ID: 252, soultimate_name: "Ropin' Robbin'", power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: 'A single enemy gets tied up tight and is unable to move.', target: [2], amount: [1]},

{holder: 'Rockabelly', ID: 253, soultimate_name: 'Face Flop', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slams his belly into a foe.The impact hurts him too, though.', target: [], amount: []},

{holder: 'Squeeky', ID: 254, soultimate_name: 'Maruckus', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: "The infernal sound of maracas gradually drops enemies' HP.", target: [], amount: []},

{holder: 'Rawry', ID: 255, soultimate_name: 'Loud and Proud', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: "A booming noise from the speakers steadily drops enemies' HP.", target: [], amount: []},

{holder: 'Buhu', ID: 256, soultimate_name: 'Boohoo Blast', power: '30', element: 'None', InsType: [8], SoultInsLevel: [1], description: 'Blasts unpleasant energy at her foes and slows them down.', target: [2, 2], amount: [3, 1]},

{holder: 'Flumpy', ID: 257, soultimate_name: 'Awfully Awkward', power: '70', element: 'None', InsType: [8], SoultInsLevel: [2], description: 'Blasts unpleasant energy at her foes and slows them down.', target: [2, 2], amount: [3, 1]},

{holder: 'Skreek', ID: 258, soultimate_name: 'Meet the Reaper', power: '---', element: 'None', InsType: [10], SoultInsLevel: [2], description: 'Sends his foes(and their stats) into depths of despair.', target: [2, 2], amount: [3, 1]},

{holder: 'Manjimutt', ID: 259, soultimate_name: 'Creepy Superbite', power: '19x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Bits all of his enemies in a frenzy. Pretty creepy, actually ...', target: [], amount: []},

{holder: 'Multimutt', ID: 260, soultimate_name: 'Superbite Twin', power: '25x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Twice the head means twice the bites for the same number of foes.', target: [], amount: []},

{holder: 'Sir Berus', ID: 261, soultimate_name: 'Stygian Slingshot', power: '130', element: 'None', InsType: [], SoultInsLevel: [], description: 'Shoots rocks gathered from the underworld at his opponents.', target: [], amount: []},

{holder: 'Furgus', ID: 262, soultimate_name: 'Fluffy Dispel', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Enemies are gently relieved of all their positive effects.', target: [], amount: []},

{holder: 'Furdinand', ID: 263, soultimate_name: 'Bushy World', power: '270', element: 'None', InsType: [], SoultInsLevel: [], description: 'Furdinand blows himself up, damaging all enemies and allies.', target: [], amount: []},

{holder: 'Nosirs', ID: 264, soultimate_name: 'Ah, Ah, Ah--', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: "The trio's endless denials manage to confuse the enemy.", target: [2], amount: [3]},

{holder: 'Dismarelda', ID: 265, soultimate_name: 'Dismartillery', power: '40', element: 'None', InsType: [2], SoultInsLevel: [1], description: 'Covers her foes in gloomy fumes that then lower their STR.', target: [2, 2], amount: [3, 1]},

{holder: 'Chatalie', ID: 266, soultimate_name: 'Big Mouth', power: '18x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Bites her opponents with a big-toothed grin.', target: [], amount: []},

{holder: 'Nagatha', ID: 267, soultimate_name: 'Badger Bite', power: '21x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Bis her opponents while complaining.', target: [], amount: []},

{holder: 'Papa Windbag', ID: 268, soultimate_name: 'Boastful Dance', power: '---', element: 'None', InsType: [13, 17], SoultInsLevel: [1], description: 'Papa Windbag sings his own praises and restores HP in the process.', target: [0, 1], amount: [3, 1, 1]},

{holder: 'Ben Tover', ID: 269, soultimate_name: 'Squirm', power: '---', element: 'None', InsType: [10], SoultInsLevel: [1], description: 'Unpleasant wriggling reduces all enemy stats.', target: [2, 2], amount: [3, 1]},

{holder: 'Cheeksqueek', ID: 270, soultimate_name: 'Stinky Smog', power: '---', element: 'None', InsType: [8], SoultInsLevel: [1], description: 'Emits an evil fart that significantly lowers the SPD of enemies.', target: [2, 2], amount: [3, 1]},

{holder: 'Cuttincheez', ID: 271, soultimate_name: 'Toxic Gas', power: '---', element: 'None', InsType: [8], SoultInsLevel: [3], description: 'Emits an evil fart that significantly lowers the SPD of enemies.', target: [2, 2], amount: [3, 1]},

{holder: 'Toiletta', ID: 272, soultimate_name: 'Curse You!', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'A powerful curse causes enemy HP to steadly drop away.', target: [], amount: []},

{holder: 'Foiletta', ID: 273, soultimate_name: 'Cursed Love', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'A curse from a book causes enemy HP to rapidly drop away.', target: [], amount: []},

{holder: 'Sproink', ID: 274, soultimate_name: 'Squealing Boil', power: '160', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Roats the enemy with flames fired from his boiling-hot nose.', target: [], amount: []},

{holder: 'Compunzer', ID: 275, soultimate_name: 'Lamest Joke', power: '---', element: 'None', InsType: [8], SoultInsLevel: [3], description: 'Tells a joke so badly that his foes slow down to a crawl...', target: [2, 2], amount: [3, 1]},

{holder: 'Lamedian', ID: 276, soultimate_name: 'Millennium\nof Lame', power: '---', element: 'None', InsType: [8], SoultInsLevel: [3], description: 'Tells a joke so badly that his foes slow down to a crawl...', target: [2, 2], amount: [3, 1]},

{holder: 'Grumples', ID: 277, soultimate_name: 'Scary Wrinkles', power: '100', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Steals HP from foes with her staff and gives it to her allies.', target: [], amount: []},

{holder: 'Everfore', ID: 278, soultimate_name: 'Beauty Beam', power: '130', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Steals HP from foes with her staff and gives it to her allies.', target: [], amount: []},

{holder: 'Eterna', ID: 279, soultimate_name: 'Undying Drain', power: '140', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Steals HP from foes with her staff and gives it to her allies.', target: [], amount: []},

{holder: 'Insomni', ID: 280, soultimate_name: 'Never Sleep Ever', power: '---', element: 'None', InsType: [10], SoultInsLevel: [2], description: "Lowers all her enemies' stats with just one look.", target: [2, 2], amount: [3, 1]},

{holder: 'Sandi', ID: 281, soultimate_name: 'Unwaking Dream', power: '140', element: 'None', InsType: [10], SoultInsLevel: [1], description: 'Sends a wave of evil at her foes and lowers all of their stats.', target: [2, 2], amount: [3, 1]},

{holder: 'Arachnus', ID: 282, soultimate_name: 'Spider Smash', power: '300', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Legendary spider power inflicts earth damage on an enemy.', target: [], amount: []},

{holder: 'Arachnia', ID: 283, soultimate_name: 'Spider Crash', power: '290', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Infamous spider power inflicts earth damage on an enemy.', target: [], amount: []},

{holder: 'Cricky', ID: 284, soultimate_name: 'Morning Shower', power: '60', element: 'Water', InsType: [], SoultInsLevel: [], description: 'A powerful morning shower causes damage to all enemies.', target: [], amount: []},

{holder: 'Noko', ID: 285, soultimate_name: 'Noko Smile', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores HP for his allies with his soothing Noko smile.', target: [], amount: []},

{holder: 'Bloominoko', ID: 286, soultimate_name: 'Lucky Smile', power: '150', element: 'None', InsType: [], SoultInsLevel: [], description: 'Recover HP for his allies with a smile that brings good fortune.', target: [], amount: []},

{holder: 'Pandanoko', ID: 287, soultimate_name: 'Panda Smile', power: '170', element: 'None', InsType: [], SoultInsLevel: [], description: 'Recover HP for his allies with a rare black and-white smile.', target: [], amount: []},

{holder: 'Snaggly', ID: 288, soultimate_name: 'Tossabout', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Restless tossing and turning confuses all enemies.', target: [2], amount: [3]},

{holder: 'Whinona', ID: 289, soultimate_name: 'Whining Wail', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Endless griping and groaning confuses all enemies.', target: [2], amount: [3]},

{holder: 'Heheheel', ID: 290, soultimate_name: 'In da Funny Bone', power: '85', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores HP for allies. Laughter really is the best medicine.', target: [], amount: []},

{holder: 'Croonger', ID: 291, soultimate_name: 'Eel Life', power: '21x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Bits his enemies as he sings classis tunes.', target: [], amount: []},

{holder: 'Urnaconda', ID: 292, soultimate_name: 'Venoconda', power: '80', element: 'None', InsType: [], SoultInsLevel: [], description: 'Emits a poison mist that gradually drains HP of enemies.', target: [], amount: []},

{holder: 'Fishpicable', ID: 293, soultimate_name: 'Hateful Charge', power: '55', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Charges up with enemy HP (and shares some with his allies).', target: [], amount: []},

{holder: 'Rageon', ID: 294, soultimate_name: 'Vengeance', power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: 'Charges into an enemy. Deals huge damage.', target: [], amount: []},

{holder: 'Tunatic', ID: 295, soultimate_name: 'Frenzied Rage', power: '125', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Calls forth his fiery rage to burn his foes to crisp.', target: [], amount: []},

{holder: 'Flushback', ID: 296, soultimate_name: 'Sucksorcism', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Purifies all allies by pulling bad spirits out of them.', target: [], amount: []},

{holder: 'Vacuumory', ID: 297, soultimate_name: 'Vacuucism', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Purifies all allies by pulling bad spirits out of them.', target: [], amount: []},

{holder: 'Irewig', ID: 298, soultimate_name: 'Flailing Tail', power: '75', element: 'None', InsType: [], SoultInsLevel: [], description: 'An angry tail swipe that often misses but can score a critical hit.', target: [], amount: []},

{holder: 'Firewig', ID: 299, soultimate_name: 'Flaming Tail', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'An angry tail swipe that often misses but can score a critical hit.', target: [], amount: []},

{holder: 'Draggie', ID: 300, soultimate_name: 'Draggie Stone', power: '100', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Shakes the earth beneath his foes with a sacred crystal.', target: [], amount: []},

{holder: 'Dragon Lord', ID: 301, soultimate_name: 'Dragon Rock', power: '190', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Drops a boulder on his foes with the power of the crystal.', target: [], amount: []},

{holder: 'Azure Dragon', ID: 302, soultimate_name: 'Dragon Falls', power: '200', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Creates a massive waterfall that simply overwhelms his foes.', target: [], amount: []},

{holder: 'Mermaidyn', ID: 303, soultimate_name: 'Beach Wave', power: '120', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Summons waves and sends them crashing into all enemies.', target: [], amount: []},

{holder: 'Mermadonna', ID: 304, soultimate_name: 'Tidal Wave', power: '190', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Sends foaming white waves smashing into all enemies.', target: [], amount: []},

{holder: 'Mermother', ID: 305, soultimate_name: 'Big Wave', power: '200', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Assails all enemies with colossal crashing waves.', target: [], amount: []},

{holder: 'Lady Longnek', ID: 306, soultimate_name: "Twist 'n' Tangle", power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: 'A neck-streching strike that always hits home.', target: [], amount: []},

{holder: 'Daiz', ID: 307, soultimate_name: 'Spacing Out', power: '80', element: 'None', InsType: [], SoultInsLevel: [], description: 'Sends an evil aura at foes. The aura will send them into a daze.', target: [2], amount: [3]},

{holder: 'Confuze', ID: 308, soultimate_name: 'Uh, Er ... Hold On.', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: 'Sends a dark aura at foes and puts them into a daze.', target: [2], amount: [3]},

{holder: 'Chummer', ID: 309, soultimate_name: 'Sharkskin Shield', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 1], description: 'Draws attacks to himself and raises DEF.', target: [0, 1], amount: [1, 1]},

{holder: 'Shrook', ID: 310, soultimate_name: 'Feedong Frenzy', power: '120', element: 'Drain', InsType: [], SoultInsLevel: [], description: 'Voraciously devours enemy HP and divides it among his allies.', target: [], amount: []},

{holder: 'Spenp', ID: 311, soultimate_name: 'Bank Breaker', power: '130', element: 'None', InsType: [15], SoultInsLevel: [1], description: 'Makes his foes forget the value of money as they toss it away!', target: [2], amount: [3]},

{holder: 'Almi', ID: 312, soultimate_name: 'Eternal Debt', power: '160', element: 'None', InsType: [15], SoultInsLevel: [1], description: 'Sends foes into dept by scattering their money uncontrollably.', target: [2], amount: [3]},

{holder: 'Babblong', ID: 313, soultimate_name: 'Babbleblast', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps a foe with his nose. May cancel Soultimate Moves.', target: [], amount: []},

{holder: 'Bananose', ID: 314, soultimate_name: 'Banana Splat', power: '200', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slaps a foe with his nose. May cancel Soultimate Moves.', target: [], amount: []},

{holder: 'Draaagin', ID: 315, soultimate_name: 'Aaand Release', power: '230', element: 'Ice', InsType: [], SoultInsLevel: [], description: 'Finally gets around to breathing a burst of watery breath.', target: [], amount: []},

{holder: 'SV Snaggerjag', ID: 316, soultimate_name: "A Fisher's Life", power: '160', element: 'Water', InsType: [], SoultInsLevel: [], description: 'Hooks a huge whale that blasts foes with its watery breath.', target: [], amount: []},

{holder: 'Copperled', ID: 317, soultimate_name: "I'll Take the Lead!", power: '---', element: 'None', InsType: [1], SoultInsLevel: [2], description: "Gives an order that heightens allies' morale and STR.", target: [1], amount: [1]},

{holder: 'Cynake', ID: 318, soultimate_name: 'Sulky Soul', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Undoes all good effects on foes by making them overly cynical.', target: [], amount: []},

{holder: 'Slitheref', ID: 319, soultimate_name: 'Venomous Feint', power: '---', element: 'None', InsType: [2], SoultInsLevel: [2], description: 'Sprays a venomous wave that decreases enemy STR.', target: [2, 2], amount: [3, 1]},

{holder: 'Venoct', ID: 320, soultimate_name: 'Octo Snake', power: '25x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Repeatedly bits his foes with his aura-filled dragon scarf.', target: [], amount: []},

{holder: 'Shadow Venoct', ID: 321, soultimate_name: 'Shadow Dragon', power: '24x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Repeatedly bits his foes with his dragon scarf made of aura.', target: [], amount: []},

{holder: 'Shogunyan', ID: 322, soultimate_name: 'Bonito Blade', power: '25x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cuts his opponents- not with his claws, but with his trusty sword.', target: [], amount: []},

{holder: 'Komashura', ID: 323, soultimate_name: 'Shura Shower', power: '170', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Broils all of his foes with fearsome flames.', target: [], amount: []},

{holder: 'Gilgaros', ID: 324, soultimate_name: 'Golden Beatdown', power: '350', element: 'None', InsType: [], SoultInsLevel: [], description: 'Crushes a single foe with all the might of a legendary Oni.', target: [], amount: []},

{holder: 'Spoilerina', ID: 325, soultimate_name: 'Finale Spoiler', power: '---', element: 'None', InsType: [13, 17], SoultInsLevel: [1], description: 'A divine dance that heals HP and maxed out all stats.', target: [0, 1], amount: [3, 1, 1]},

{holder: 'Elder Bloom', ID: 326, soultimate_name: 'Full Bloom', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Revives allies and restores their HP with cherry-blossom power.', target: [], amount: []},

{holder: 'Poofessor', ID: 327, soultimate_name: 'Pooped out', power: '150', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'A wave of woe hits all foes and can confuse them too.', target: [2], amount: [3]},

{holder: 'Dandoodle', ID: 328, soultimate_name: 'Handsome Grin', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Fully recovers HP of his allies with a truly handsome smile.', target: [], amount: []},

{holder: 'Slurpent', ID: 329, soultimate_name: "Lick 'Em Good!", power: '32x8', element: 'None', InsType: [], SoultInsLevel: [], description: 'Licks all enemies with eight tongues and then chews them up.', target: [], amount: []},

{holder: 'Sapphinyan', ID: 330, soultimate_name: 'Pure-Blue Paws', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all opponents with his beautiful sapphire paws.', target: [], amount: []},

{holder: 'Emenyan', ID: 331, soultimate_name: 'Cutie Paws', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all opponents with his adorable emerald paws.', target: [], amount: []},

{holder: 'Rubinyan', ID: 332, soultimate_name: 'Ruby Boogie', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all opponents with his shiny ruby paws.', target: [], amount: []},

{holder: 'Topanyan', ID: 333, soultimate_name: 'Glittering Paws', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all opponents with rich topaz powers.', target: [], amount: []},

{holder: 'Dianyan', ID: 334, soultimate_name: 'Perfect Paws', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all opponents with his unbreakable diamond paws.', target: [], amount: []},

{holder: 'Melonyan', ID: 335, soultimate_name: 'Melon Masher', power: '22x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pummels all enemies with paws powered by pure melon juice.', target: [], amount: []},

{holder: 'Oranyan', ID: 336, soultimate_name: 'Vitameow C', power: '150', element: 'None', InsType: [], SoultInsLevel: [], description: 'Heals all allies with a burst of pure vitamin C.', target: [], amount: []},

{holder: 'Kiwinyan', ID: 337, soultimate_name: 'Stubble Barrier', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Maxes DEF with his tiny hairs and attracts attacks.', target: [0, 1], amount: [1, 1]},

{holder: 'Grapenyan', ID: 338, soultimate_name: 'Grape Buddies', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Confuses all foes with a waft of fruity goodness.', target: [2], amount: [3]},

{holder: 'Strawbnyan', ID: 339, soultimate_name: 'Strawberry Roar', power: '140', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'Damages all enemies with a blast of strawberry breath.', target: [], amount: []},

{holder: 'Watermelnyan', ID: 340, soultimate_name: 'Seed Nyattack', power: '32x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Spits a string of stining seeds at all enemies.', target: [], amount: []},

{holder: 'Robokapp', ID: 341, soultimate_name: 'Kappa Cutter', power: '30x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all enemies with a hidden razor blade.', target: [], amount: []},

{holder: 'Robokoma', ID: 342, soultimate_name: 'Koma Kannon', power: '270', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks a single foe with a beam of country power!', target: [], amount: []},

{holder: 'Robogramps', ID: 343, soultimate_name: 'Eat This!', power: '230', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks a single foe with a beam of advanced hunger', target: [], amount: []},

{holder: 'Robomutt', ID: 344, soultimate_name: "Pooch a' Splode", power: '250', element: 'None', InsType: [], SoultInsLevel: [], description: 'Explodes and damages all enemies and allies.', target: [], amount: []},

{holder: 'Robonoko', ID: 345, soultimate_name: 'Soothing Smile', power: '150', element: 'None', InsType: [], SoultInsLevel: [], description: "An awkward robotic smile recovers all allies' HP.", target: [], amount: []},

{holder: 'Robodraggie', ID: 346, soultimate_name: 'Dragonic Burn', power: '230', element: 'None', InsType: [], SoultInsLevel: [], description: 'Beams of futuristic dragon energy blast a single foe.', target: [], amount: []},

{holder: 'Wondernyan', ID: 347, soultimate_name: 'Vagabond Blade', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: "Slices all foes with his beloved wanderer's sword.", target: [], amount: []},

{holder: 'Robonyan F', ID: 348, soultimate_name: 'Farewell Blast', power: '300', element: 'None', InsType: [], SoultInsLevel: [], description: 'Explodes and damages all enemies and allies.', target: [], amount: []},

{holder: 'Sailornyan', ID: 349, soultimate_name: 'Lovely Meow', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: 'The potent power of feline feminity heals all allies.', target: [], amount: []},

{holder: 'Machonyan', ID: 350, soultimate_name: 'Tiger Meow', power: '210', element: 'None', InsType: [], SoultInsLevel: [], description: 'Dives off the ropes to attack so hard he hurts himself.', target: [], amount: []},

{holder: 'Hovernyan', ID: 351, soultimate_name: 'Gusty Cross Paw', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'Builds up and then hits a single foe with a stunning tackle.', target: [], amount: []},

{holder: 'Darknyan', ID: 352, soultimate_name: 'Night Claw', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks a single foe from the shadows. High critical chance.', target: [], amount: []},

{holder: 'Jibakoma', ID: 353, soultimate_name: 'Swirly Nyanball', power: '230', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all enemies with balls of energy drawn from allies.', target: [], amount: []},

{holder: 'Jetnyan', ID: 354, soultimate_name: 'Paws of Flying', power: '15x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks all enemies with paws powered by jumbo-jet engines.', target: [], amount: []},

{holder: 'Unfairy', ID: 355, soultimate_name: 'Unfairy Kraft', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'An uncommonly unfair curse rapidly decreases foe HP.', target: [], amount: []},

{holder: 'Unkaind', ID: 356, soultimate_name: 'Unkaind Kiss', power: '180', element: 'None', InsType: [], SoultInsLevel: [], description: 'Restores HP to all allies with her alluring aura.', target: [], amount: []},

{holder: 'Untidy', ID: 357, soultimate_name: 'Untidey Keeper', power: '---', element: 'None', InsType: [16, 5], SoultInsLevel: [1, 3], description: 'Raises DEF and directs all attacks to this character.', target: [0, 1], amount: [1, 1]},

{holder: 'Unpleasant', ID: 358, soultimate_name: 'Unpleasant Kurse', power: '180', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'A nasty curse causes all enemies to get confused.', target: [2], amount: [3]},

{holder: 'Unkeen', ID: 359, soultimate_name: 'Unkeen Krack', power: '265', element: 'None', InsType: [], SoultInsLevel: [], description: 'A punch capable of destroying all. Strikes one enemy.', target: [], amount: []},

{holder: 'Grublappa', ID: 360, soultimate_name: 'Lickety-Lick', power: '40x3', element: 'None', InsType: [], SoultInsLevel: [], description: 'Unfurls his lenghty tongue and does damage to all foes.', target: [], amount: []},

{holder: 'Madmunch', ID: 361, soultimate_name: 'Dirty Trick', power: '100', element: 'None', InsType: [2], SoultInsLevel: [1], description: 'Focuses all his rage to attack and sap the STR of his foes.', target: [2, 2], amount: [3, 1]},

{holder: 'Badsmella', ID: 362, soultimate_name: 'Upward Tornado', power: '220', element: 'Wind', InsType: [], SoultInsLevel: [], description: "Calls a tornado strong enough to mess up the enemy's clothes.", target: [], amount: []},

{holder: 'Mad Kappa', ID: 363, soultimate_name: 'Mega Wave', power: '170', element: 'Water', InsType: [], SoultInsLevel: [], description: "Harnesses the power of a river's flow to do damage to a foe.", target: [], amount: []},

{holder: 'Shamasol', ID: 364, soultimate_name: 'Umbrella Gust', power: '90', element: 'Wind', InsType: [], SoultInsLevel: [], description: 'Strikes all enemies with a dry gust of wind from a traditional Yo-kai.', target: [], amount: []},

{holder: 'Gnomine', ID: 365, soultimate_name: 'Innocent World', power: '---', element: 'None', InsType: [13], SoultInsLevel: [1], description: "The power of good, clean fun steadily restores allies' HP.", target: [], amount: [3]},

{holder: 'Defectabull', ID: 366, soultimate_name: 'Soothing Fortune', power: '70', element: 'None', InsType: [], SoultInsLevel: [], description: "Good fortune causes all allies' HP to recover.", target: [], amount: []},

{holder: 'Feargus', ID: 367, soultimate_name: 'Fluffy Dispel', power: '---', element: 'None', InsType: [], SoultInsLevel: [], description: 'Enemies are gently relieved of all their positive effects.', target: [], amount: []},

{holder: 'Scaremaiden', ID: 368, soultimate_name: 'Beach Wave', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Summons waves and sends them crashing into all enemies.', target: [], amount: []},

{holder: 'Wrongnek', ID: 369, soultimate_name: "Twist 'n' Tangle", power: '140', element: 'None', InsType: [], SoultInsLevel: [], description: 'A neck-streching strike that always hits home.', target: [], amount: []},

{holder: 'Grumpus Khan', ID: 370, soultimate_name: 'Awkward Silence', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Makes the enemy so awkward that they all get confused.', target: [2], amount: [3]},

{holder: 'Groupus Khan', ID: 371, soultimate_name: 'Awkward Moment', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Makes the enemy so awkward that they all get confused.', target: [2, 1], amount: [3, 1]},

{holder: 'Slumberhog', ID: 372, soultimate_name: 'Snooze Bruiser', power: '110', element: 'None', InsType: [], SoultInsLevel: [], description: 'Slams hard into an enemy without even waking up.', target: [], amount: []},

{holder: 'Snortlehog', ID: 373, soultimate_name: 'Hog Wild', power: '30x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'A battle-hardened blaze of blows that strikes all foes.', target: [], amount: []},

{holder: 'Panja Pupil', ID: 374, soultimate_name: "I'm a Panda!", power: '90', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks a single foe with the full power of the Panja.', target: [], amount: []},

{holder: 'Panja Pro', ID: 375, soultimate_name: 'Panjitsu', power: '170', element: 'None', InsType: [], SoultInsLevel: [], description: 'Attacks a single foe with the full power of the Panja.', target: [], amount: []},

{holder: 'Samureel', ID: 376, soultimate_name: 'Eelergetic', power: '---', element: 'None', InsType: [1], SoultInsLevel: [1], description: "Employs nutritious eeliness to increase all allies' STR.", target: [1], amount: [1]},

{holder: 'Time Keeler', ID: 377, soultimate_name: 'Bored Slice', power: '31x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Strikes all enemies with his swords just because he can.', target: [], amount: []},

{holder: 'Takoyakid', ID: 378, soultimate_name: 'Octopick', power: '25x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pokes all enemies repeatedly with his little stick.', target: [], amount: []},

{holder: 'Takoyaking', ID: 379, soultimate_name: 'Octopoke', power: '23x7', element: 'None', InsType: [], SoultInsLevel: [], description: 'Pokes all enemies repeatedly with his little stick.', target: [], amount: []},

{holder: 'Danke Sand', ID: 380, soultimate_name: 'Thand You', power: '120', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Attacks all enemies with energy from under the earth.', target: [], amount: []},

{holder: 'No Sandkyu', ID: 381, soultimate_name: 'No Thand You', power: '160', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Attacks all enemies with energy from under the earth.', target: [], amount: []},

{holder: 'Sumodon', ID: 382, soultimate_name: 'Slapdown', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: "A stunning slap that can cancel a foe's Soultimate Move.", target: [], amount: []},

{holder: 'Yokozudon', ID: 383, soultimate_name: 'Smackdown', power: '160', element: 'None', InsType: [], SoultInsLevel: [], description: "A stunning slap that can cancel a foe's Soultimate Move.", target: [], amount: []},

{holder: 'Whateverest', ID: 384, soultimate_name: 'Oh!', power: '120', element: 'Earth', InsType: [], SoultInsLevel: [], description: 'Musters the power of immovable mountains to attack all foes.', target: [], amount: []},

{holder: 'Whatuption', ID: 385, soultimate_name: 'Gleeruption', power: '160', element: 'Fire', InsType: [], SoultInsLevel: [], description: 'A massive blast of magma rains fire damage on all foes.', target: [], amount: []},

{holder: 'Happycane', ID: 386, soultimate_name: 'Make You Happy', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cheers everyone up with her cute moves, healing HP all round', target: [], amount: []},

{holder: 'Starrycane', ID: 387, soultimate_name: 'Starry Bright', power: '120', element: 'None', InsType: [], SoultInsLevel: [], description: 'Cheers everyone up with her cute moves, healing HP all round', target: [], amount: []},

{holder: 'Snottle', ID: 430, soultimate_name: 'Icky Picky', power: '---', element: 'None', InsType: [14], SoultInsLevel: [1], description: 'Confuses all enemies by striking an oddly defiant  nose-picking pose.', target: [2], amount: [3]},

{holder: 'Moximous N', ID: 431, soultimate_name: 'Mighty Moxie', power: '---', element: 'None', InsType: [13, 17], SoultInsLevel: [1], description: 'Strikes Moxie pose, recovering HP and getting even more powerful.', target: [0, 1], amount: [3, 1, 1]},

{holder: 'Moximous K', ID: 432, soultimate_name: 'Mega Moxie', power: '---', element: 'None', InsType: [13, 17], SoultInsLevel: [1], description: 'Reaches maximum strength while restoring HP in the moxie pose.', target: [0, 1], amount: [3, 1, 1]},

{holder: 'Jibanyan S', ID: 433, soultimate_name: 'Paws of Fury', power: '20x5', element: 'None', InsType: [], SoultInsLevel: [], description: 'Punches all opponents with paws trained on moving vehicles.', target: [], amount: []},

{holder: 'Komasan S', ID: 434, soultimate_name: 'Sprirt Dance', power: '100', element: 'None', InsType: [], SoultInsLevel: [], description: "Summons will-o'-the-wisps to damage his enemies.", target: [], amount: []},

{holder: 'Komajiro S', ID: 435, soultimate_name: 'Wild Zaps', power: '85', element: 'Lightning', InsType: [], SoultInsLevel: [], description: 'Calls down lighting upon his opponents.', target: [], amount: []},

{holder: 'Darkyubi', ID: 436, soultimate_name: 'Alpha Omega', power: '200', element: 'None', InsType: [], SoultInsLevel: [], description: 'Unleashes a terrifying darkness, steadily lowering the HP of the enemy.', target: [], amount: []},

{holder: 'Illuminoct', ID: 437, soultimate_name: 'Dragon Flash', power: '24x10', element: 'None', InsType: [], SoultInsLevel: [], description: 'Repeatedly bits his foes with his aura-filled dragon scarf.', target: [], amount: []},

{holder: 'Gargaros', ID: 438, soultimate_name: 'Iron Anger', power: '350', element: 'None', InsType: [], SoultInsLevel: [], description: "Pulverizes one enemy in a display of Gargaros's awesome power.", target: [], amount: []},

{holder: 'Ogralus', ID: 439, soultimate_name: 'Iron Frost', power: '350', element: 'None', InsType: [], SoultInsLevel: [], description: "Pulverizes one enemy in a display of Ogralus's awesome power.", target: [], amount: []},

{holder: 'Orcanos', ID: 440, soultimate_name: 'Nightmare Beat', power: '350', element: 'None', InsType: [], SoultInsLevel: [], description: "Pulverizes one enemy in a display of Orcanos's awesome power.", target: [], amount: []},

]

var GivenStats = localStorage.getItem('_soultimate_data');
var SavingStats = JSON.stringify(soultimates[GivenStats-1]);
SavingStats = btoa(SavingStats)
localStorage.setItem("_trans_soultimate_data", SavingStats);

function GetSoultimateID(GivenStats){ // Damage Calc Function
	var GivenStats = localStorage.getItem('_soultimate_yokai_attacker_data');
	var SavingStats = JSON.stringify(soultimates[GivenStats-1]);
	SavingStats = btoa(SavingStats)
	localStorage.setItem("_trans_attacker_yokai_soultimate_data", SavingStats);
	getAttack()
}