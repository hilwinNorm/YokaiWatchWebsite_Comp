
var side_bar = document.getElementById('side_bar')

side_bar.innerHTML += `
<button class="side-button" id="medallium-btn">Strategy Medallium</button>
	<button class="side-button">Tier Sheet</button>
	<button class="side-button" id="damageCalc-btn">Damage Calculator</button>
	<button class="side-button">Soul List</button>
	
	<button class="side-button">Equipment List</button>
	<button class="side-button">Attacks, Techniques, Soultimates</button>
	<button class="side-button">Yo-Kai Skills</button>
	
	<button class="side-button" id="TeamBuild-btn">Build Team</button>
	
	<a href='https://discord.gg/wyWbEhhGwm'><button class="side-button">Discord</button></a>
`


var home_btn = document.getElementById('home-btn');

var about_btn = document.getElementById('about-btn');

var contact_btn = document.getElementById('contact-btn');

var logo_js = document.getElementById('logo-js');

var medallium_btn = document.getElementById('medallium-btn');

var damageCalc_btn = document.getElementById('damageCalc-btn')

var teamBuild_btn = document.getElementById('TeamBuild-btn')

var head = document.head

var faviconLink = document.createElement('link');

faviconLink.rel = 'icon';

faviconLink.href = 'Content/Graphics/Whisper.ico';

head.appendChild(faviconLink);

function redirect(name){
	if (page != `${name}.html`){
		console.log('Redirecting...');
		window.location.assign(`./${name}.html`);
		console.log('Done!');
  }
  else{
	  noredirect(1)
  }
}

function noredirect(num){
	console.log("Can't redirect to the page");
	switch(num){
		case NaN:
			console.log("Unknown issue");
			break;
		case 1:
			console.log("Already broadcasting");
			break;
		case 2:
			console.log("The page is unavaliable");
			break;
	}
}

home_btn.addEventListener('click', () => {
	//pressing_button(home_btn)
	
	redirect("index")
});

about_btn.addEventListener('click', () => {
	//pressing_button(about_btn)
  
	redirect("about")
});

contact_btn.addEventListener('click', () => {
	//pressing_button(contact_btn)
	
	redirect("contact")
});


logo_js.addEventListener('click', () => {
	//pressing_button(home_btn)
	
	redirect("index")
});

medallium_btn.addEventListener('click', () => {
	//pressing_button(home_btn)
	
	redirect("medallium")
});

damageCalc_btn.addEventListener('click', () => {
	
	redirect("DamageCalc")
})

teamBuild_btn.addEventListener('click', () => {
	
	redirect("TeamBuild")
})

var path_location = window.location.pathname;
var page = path_location.split("/").pop();
console.log( page );

console.log('JS LOADED UP');	