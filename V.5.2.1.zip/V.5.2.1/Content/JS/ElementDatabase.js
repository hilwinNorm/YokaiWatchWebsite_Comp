const elements = [
  {
    element: "Torrent",
    ID: 1,
    element_type: "Water",
    power: "20-90",
	target: 1
  },
  {
    element: "Rapids",
    ID: 2,
    element_type: "Water",
    power: "50-110",
	target: 1
  },
  {
    element: "WaterFall",
    ID: 3,
    element_type: "Water",
    power: "80-120",
	target: 1
  },
  {
    element: "Pebble",
    ID: 4,
    element_type: "Earth",
    power: "20-90",
	target: 1
  },
  {
    element: "Rockslide",
    ID: 5,
    element_type: "Earth",
    power: "50-110",
	target: 1
	
  },
  {
    element: "Meteor",
    ID: 6,
    element_type: "Earth",
    power: "80-120",
	target: 1
  },
  {
    element: "Fire",
    ID: 7,
    element_type: "Fire",
    power: "20-90",
	target: 1
  },
  {
    element: "Blaze",
    ID: 8,
    element_type: "Fire",
    power: "50-110",
	target: 1
  },
  {
    element: "Incinerate",
    ID: 9,
    element_type: "Fire",
    power: "80-120",
	target: 1
  },
  {
    element: "Whirlwind",
    ID: 10,
    element_type: "Wind",
    power: "20-90",
	target: 1
  },
  {
    element: "Tornado",
    ID: 11,
    element_type: "Wind",
    power: "50-110",
	target: 1
  },
  {
    element: "Storm",
    ID: 12,
    element_type: "Wind",
    power: "80-120",
	target: 1
  },
  {
    element: "Hail",
    ID: 13,
    element_type: "Ice",
    power: "20-90",
	target: 1
  },
  {
    element: "Frost",
    ID: 14,
    element_type: "Ice",
    power: "50-110",
	target: 1
  },
  {
    element: "Blizzard ",
    ID: 15,
    element_type: "Ice",
    power: "80-120",
	target: 1
  },
  {
    element: "Shock",
    ID: 16,
    element_type: "Lightning",
    power: "20-90",
	target: 1
  },
  {
    element: "Lightning",
    ID: 17,
    element_type: "Lightning",
    power: "50-110",
	target: 1
  },
  {
    element: "Voltage",
    ID: 18,
    element_type: "Lightning",
    power: "80-120",
	target: 1
  },
  {
    element: "Absorb",
    ID: 19,
    element_type: "Drain",
    power: "20-90",
	target: 1
  },
  {
    element: "Drain",
    ID: 20,
    element_type: "Drain",
    power: "50-110",
	target: 1
  },
  {
    element: "Reaper",
    ID: 21,
    element_type: "Drain",
    power: "80-120",
	target: 1
  },
  {
    element: "Heal",
    ID: 22,
    element_type: "Heal",
    power: "20-90",
	target: 2
  },
  {
    element: "Restore",
    ID: 23,
    element_type: "Heal",
    power: "50-110",
	target: 2
  },
  {
    element: "Paradise",
    ID: 24,
    element_type: "Heal",
    power: "80-120",
	target: 2
  }
]

var GivenStats = localStorage.getItem('_element_data');
var SavingStats = JSON.stringify(elements[GivenStats-1]);
SavingStats = btoa(SavingStats)
localStorage.setItem("_trans_element_data", SavingStats);

function GetTechniqueID(){ // Damage Calc Function
	var GivenStats = localStorage.getItem('_technique_yokai_attacker_data');
	var SavingStats = JSON.stringify(elements[GivenStats-1]);
	console.log("SavingStats",SavingStats)
	SavingStats = btoa(SavingStats)
	localStorage.setItem("_trans_attacker_yokai_technique_data", SavingStats);
	getAttack()
}
/*
if (typeof Defender !== "undefined"){
	let Attacker = document.getElementById("yokai_select2")
	const CalcButton = document.getElementById("calcButton")
	const AttackType = document.getElementById("AttackType")
	Defender.addEventListener("change", function(event){
		console.log("123")
		if (AttackType.value == "2"){
			if (localStorage.hasOwnProperty('_attack_yokai_element_data')) {
				
				var GivenStats = localStorage.getItem('_attack_yokai_element_data');
				console.log(GivenStats)
				var SavingStats = JSON.stringify(elements[GivenStats-1]);
				SavingStats = btoa(SavingStats)
				localStorage.setItem("_trans_attack_yokai_element_data", SavingStats);
}
			
		}
		
	});
}
*/