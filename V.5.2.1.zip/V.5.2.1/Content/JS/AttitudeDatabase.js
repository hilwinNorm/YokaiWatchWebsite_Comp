const Attitudes = [
{
	name: "Gentle",
	boost: [26, 0, 13, 0, 0]
},
{
	name: "Tender",
	boost: [52, 0, 0, 0, 0]
},
{	
	name: "Grouchy",
	boost: [26, 13, 0, 0, 0]
},
{		
	name:"Rough",
	boost: [0, 26, 0, 0, 0]
},
{		
	name:"Logical",
	boost: [0, 0, 13, 0, 13]
},
{		
	name:"Brainy",
	boost: [0, 0, 26, 0, 0]
},
{		
	name:"Careful",
	boost: [0, 0, 13, 13, 0]
},
{		
	name:"Calm",
	boost: [0, 0, 0, 26, 0]
},
{		
	name:"Twisted",
	boost: [0, 13, 0, 0,13]
},
{		
	name:"Cruel",
	boost: [0, 0, 0, 0, 26]
},
{		
	name:"Helpful",
	boost: [26, 0, 0, 0, 13]
},
{		
	name:"Devoted",
	boost: [0, 13, 0, 13, 0]
}
]