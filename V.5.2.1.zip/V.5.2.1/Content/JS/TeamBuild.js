
Slot1 = document.getElementById("Slot1")

 Slot2 = document.getElementById("Slot2")

 Slot3 = document.getElementById("Slot3")

 Slot4 = document.getElementById("Slot4")

 Slot5 = document.getElementById("Slot5")

 Slot6 = document.getElementById("Slot6")

Eq1 = document.getElementById("Eq1");

Eq2 = document.getElementById("Eq2")

Eq3 = document.getElementById("Eq3")

Eq4 = document.getElementById("Eq4")

Eq5 = document.getElementById("Eq5")

Eq6 = document.getElementById("Eq6")

var selectedImage = null;
let S_RankSlot1 = document.getElementById('S_Rank1');
let S_RankSlot2 = document.getElementById('S_Rank2');
let A_RankSlot1 = document.getElementById('A_Rank1');
let A_RankSlot2 = document.getElementById('A_Rank2');
var SRanksUsed = 0;
var ARanksUsed = 0;
		
		
	function selectImage(image) {
  if (selectedImage && selectedImage !== image) {
    selectedImage.classList.remove('selected');
  }
  image.classList.toggle('selected');
  selectedImage = image;
		}	
	
	
	
	function moveImage(slot) {
  if (!selectedImage) {
    console.error('No image selected!');
    return;
  }
  console.log(selectedImage)
  const imageIndex = parseInt(selectedImage.getAttribute('data-index'), 10);
  const slotIndex = parseInt(slot.getAttribute('data-index'), 10);
  console.log(imageIndex);
  console.log(slotIndex);
  console.log(selectedImage.getAttribute('rank-index'))
  if (imageIndex === slotIndex) {
    console.log('Image already in that slot!');
    return;
  }
  const slots = document.querySelectorAll('.image-slots .slot');
  for (let i = 0; i < slots.length; i++) {
    const currentSlot = slots[i];
    const currentImage = currentSlot.querySelector('.image-container');
    if (currentImage && parseInt(currentImage.getAttribute('data-index'), 10) === imageIndex) {
      currentSlot.classList.remove('has-image');
      currentImage.remove();
    }
  }
  
  if (slot.getAttribute('rank-index') == "S"){
	  if (SRanksUsed == 1){
		  S_RankSlot1.src = "Content/Graphics/S_RankUnincluded.jpg"
	  }
	  else if (SRanksUsed == 2){
		  S_RankSlot2.src = "Content/Graphics/S_RankUnincluded.jpg"
	  }
	  SRanksUsed -= 1
	  console.log("SRanksUsed", SRanksUsed)
  }
  else if(slot.getAttribute('rank-index') == "A"){
	  if (ARanksUsed == 1){
		  A_RankSlot1.src = "Content/Graphics/A_RankUnincluded.jpg"
	  }
	  else if (ARanksUsed == 2){
		  A_RankSlot2.src = "Content/Graphics/A_RankUnincluded.jpg"
	  }
	  ARanksUsed -= 1
	  console.log("ARanksUsed", ARanksUsed)
  }
  if (selectedImage.getAttribute('rank-index') == "S"){
	  if (SRanksUsed == 0){
		  S_RankSlot1.src = "Content/Graphics/S_RankIncluded.jpg"
	  }
	  else if (SRanksUsed == 1){
		  S_RankSlot2.src = "Content/Graphics/S_RankIncluded.jpg"
	  }
	  SRanksUsed += 1
	  console.log("SRanksUsed", SRanksUsed)
  }
  else if (selectedImage.getAttribute('rank-index') == "A"){
	  if (ARanksUsed == 0){
		  A_RankSlot1.src = "Content/Graphics/A_RankIncluded.jpg"
	  }
	  else if (ARanksUsed == 1){
		  A_RankSlot2.src = "Content/Graphics/A_RankIncluded.jpg"
	  }
	  ARanksUsed += 1
	  console.log("ARanksUsed", ARanksUsed)
  }
  
  slot.src = selectedImage.src;
  slot.setAttribute('data-index', imageIndex);
  slot.setAttribute('rank-index', selectedImage.getAttribute('rank-index'));
  slot.classList.add('image-container');
  slot.classList.add('has-image');
}
	


function LoadTeam(){
	let Slots = prompt("Paste encoded team here:")
	Slots = atob(Slots)
	Slots = JSON.parse(Slots)
	console.log(Slots)
	
	let YokaiPage = document.getElementById("yokai-page")
	let YokaiPageList = YokaiPage.children;
	
	for (let x = 0; x < 6; x++){
	for (let i = 0; i < YokaiPageList.length; i++) {
	const YokaiIMG = YokaiPageList[i].children[1];
	let Slot = Slots[x]
	
			if (JSON.stringify(YokaiIMG.getAttribute("data-index")) == JSON.stringify(Slot)){
				Slots[x] = YokaiIMG
			}
		}
	}
	
	console.log(Slots)
	
	selectImage(Slots[0])
	moveImage(Slot1)
	selectImage(Slots[1])
	moveImage(Slot2)
	selectImage(Slots[2])
	moveImage(Slot3)
	selectImage(Slots[3])
	moveImage(Slot4)
	selectImage(Slots[4])
	moveImage(Slot5)
	selectImage(Slots[5])
	moveImage(Slot6)
	
	Eq1.value = Slots[6]
	Eq2.value = Slots[7]
	Eq3.value = Slots[8]
	Eq4.value = Slots[9]
	Eq5.value = Slots[10]
	Eq6.value = Slots[11]
}

function SaveTeam(){
	
	 Slots = [Slot1.getAttribute("data-index"),Slot2.getAttribute("data-index"),Slot3.getAttribute("data-index"),Slot4.getAttribute("data-index"),Slot5.getAttribute("data-index"),Slot6.getAttribute("data-index"), Eq1.value, Eq2.value, Eq3.value, Eq4.value, Eq5.value, Eq6.value]
	
	console.log(Slots)
	
	var SavingTeamJSON = btoa(JSON.stringify(Slots))
	
	try {
    navigator.clipboard.writeText(SavingTeamJSON);
    alert("Succesfully copied to clipboard!");
  } catch (err) {
    console.error('Failed to copy text: ', err);
  }
}