
let Defender = document.getElementById("yokai_select1")
let DefenderHP = document.getElementById("yokai_select1-HP")
let DefenderSTR = document.getElementById("yokai_select1-STR")
let DefenderSPR = document.getElementById("yokai_select1-SPR")
let DefenderDEF = document.getElementById("yokai_select1-DEF")
let DefenderSPD = document.getElementById("yokai_select1-SPD")
let DefenderLVL = document.getElementById("yokai_select1-LVL")
let DefenderEV = document.getElementById("yokai_select1-Attitude")
let DefenderEV_Div = document.getElementById("yokai_select1-Attitude_display")

let DefenderHP_IV_Input = document.getElementById("yokai_select1-IV_HP")
let DefenderSTR_IV_Input = document.getElementById("yokai_select1-IV_STR")
let DefenderSPR_IV_Input = document.getElementById("yokai_select1-IV_SPR")
let DefenderDEF_IV_Input = document.getElementById("yokai_select1-IV_DEF")
let DefenderSPD_IV_Input = document.getElementById("yokai_select1-IV_SPD")

let DefenderSTR_Gym_Input = document.getElementById("yokai_select1-STR_Gym")
let DefenderSPR_Gym_Input = document.getElementById("yokai_select1-SPR_Gym")
let DefenderDEF_Gym_Input = document.getElementById("yokai_select1-DEF_Gym")
let DefenderSPD_Gym_Input = document.getElementById("yokai_select1-SPD_Gym")

var DefenderSTR_Gym = 0;
var DefenderSPR_Gym = 0;
var DefenderDEF_Gym = 0;
var DefenderSPD_Gym = 0;


var DefenderHP_IV = 8;
var DefenderSTR_IV = 8;
var DefenderSPR_IV = 8;
var DefenderDEF_IV = 8;
var DefenderSPD_IV = 8;

let Attacker = document.getElementById("yokai_select2")
let AttackerHP = document.getElementById("yokai_select2-HP")
let AttackerSTR = document.getElementById("yokai_select2-STR")
let AttackerSPR = document.getElementById("yokai_select2-SPR")
let AttackerDEF = document.getElementById("yokai_select2-DEF")
let AttackerSPD = document.getElementById("yokai_select2-SPD")
let AttackerLVL = document.getElementById("yokai_select2-LVL")
let AttackerEV = document.getElementById("yokai_select2-Attitude")
let AttackerEV_Div = document.getElementById("yokai_select2-Attitude_display")

let AttackerHP_IV_Input = document.getElementById("yokai_select2-IV_HP")
let AttackerSTR_IV_Input = document.getElementById("yokai_select2-IV_STR")
let AttackerSPR_IV_Input = document.getElementById("yokai_select2-IV_SPR")
let AttackerDEF_IV_Input = document.getElementById("yokai_select2-IV_DEF")
let AttackerSPD_IV_Input = document.getElementById("yokai_select2-IV_SPD")

let AttackerSTR_Gym_Input = document.getElementById("yokai_select2-STR_Gym")
let AttackerSPR_Gym_Input = document.getElementById("yokai_select2-SPR_Gym")
let AttackerDEF_Gym_Input = document.getElementById("yokai_select2-DEF_Gym")
let AttackerSPD_Gym_Input = document.getElementById("yokai_select2-SPD_Gym")

var AttackerSTR_Gym = 0;
var AttackerSPR_Gym = 0;
var AttackerDEF_Gym = 0;
var AttackerSPD_Gym = 0;

var AttackerHP_IV = 8;
var AttackerSTR_IV = 8;
var AttackerSPR_IV = 8;
var AttackerDEF_IV = 8;
var AttackerSPD_IV = 8;

let AttackType = document.getElementById("AttackType")
let DamageOutput = document.getElementById("DamageOutput")
let Defending = document.getElementById('isDefending')
let isCrit = document.getElementById("isCrit")
let isMoxie = document.getElementById('isMoxie')
let HitsDiv = document.getElementById('HitsDiv')

let DefenderImg = document.getElementById("DefenderImg")
let AttackerImg = document.getElementById("AttackerImg")

const CalcButton = document.getElementById("calcButton")

function getRandomNumberWithTwoDecimals() {
  const min = 0.9;
  const max = 1.1;
  const range = max - min;
  const randomValue = Math.random() * range + min;
  return parseFloat(randomValue.toFixed(2));
}

function getAttack(Attack){
	console.log(Attack)
	var Power = parseInt(Attack.Lv10_power);
	var ElementalResistance=1;
	var Attack;
	var ChosenAttackStat;
	var Hit_amount = "";
	var Crit = 1;
	var Defence = parseInt(DefenderDEF.value)+parseInt(Attitudes[DefenderEV.value].boost[3]);
	if (AttackType.value == "1"){
		//Attack = localStorage.getItem("_trans_attacker_yokai_move_data");
		//Attack = JSON.parse(atob(Attack));
		
		ChosenAttackStat = parseInt(AttackerSTR.value)+parseInt(Attitudes[DefenderEV.value].boost[1]);
		Hit_amount = Attack.N_Hits;
		
	}
	else if (AttackType.value == "2"){
		//Attack = localStorage.getItem("_trans_attacker_yokai_technique_data");
		//Attack = JSON.parse(atob(Attack));
		ChosenAttackStat = parseInt(AttackerSPR.value)+parseInt(Attitudes[DefenderEV.value].boost[2]);
		let Element = Attack.Element;
		console.log(Element)
		if (Element="Fire"){
			ElementalResistance = yokais[Defender.value].Fire
		}
		else if (Element="Water"){
			ElementalResistance = yokais[Defender.value].Water
		}
		else if (Element="Lightning"){
			ElementalResistance = yokais[Defender.value].Lightning
		}
		else if (Element="Earth"){
			ElementalResistance = yokais[Defender.value].Earth
		}
		else if (Element="Wind"){
			ElementalResistance = yokais[Defender.value].Wind
		}
		else if (Element="Ice"){
			ElementalResistance = yokais[Defender.value].Ice
		}
		Hit_amount = 1;
	}
	else if (AttackType.value == "3"){
		//Attack = localStorage.getItem("_trans_attacker_yokai_soultimate_data")
		//Attack = JSON.parse(atob(Attack));
		ChosenAttackStat = parseInt(AttackerSTR.value)+parseInt(Attitudes[DefenderEV.value].boost[1]);
		if (Attack.Elment !== null){
			ChosenAttackStat = parseInt(AttackerSPR.value)+parseInt(Attitudes[DefenderEV.value].boost[2]);
			let Element = Attack.element_type;
		console.log(Element)
		if (Element="Fire"){
			ElementalResistance = yokais[Defender.value].Fire
		}
		else if (Element="Water"){
			ElementalResistance = yokais[Defender.value].Water
		}
		else if (Element="Lightning"){
			ElementalResistance = yokais[Defender.value].Lightning
		}
		else if (Element="Earth"){
			ElementalResistance = yokais[Defender.value].Earth
		}
		else if (Element="Wind"){
			ElementalResistance = yokais[Defender.value].Wind
		}
		else if (Element="Ice"){
			ElementalResistance = yokais[Defender.value].Ice
		}
		}
		Hit_amount = Attack.N_Hits;		
	}
		
		RandMulti = getRandomNumberWithTwoDecimals();
		
		let DefenceMulti = 1;
		
		if (Defending.checked == true){
			DefenceMulti = 0.5
		}
		
		console.log("---")
		console.log("STR or SPR ",ChosenAttackStat)
		console.log("Power ",Power)
		console.log("Defence ",Math.round(Defence))
		console.log("Random Multiplier ",RandMulti)
		console.log("Hit amount ", Hit_amount)
		console.log("---")
		
		var Damage;
		var RawDamage;
		if (isCrit.checked == true){
			Defence = 0;
			Crit = 1.25
		}
		
		let MoxieMulti = 1;
		
		if (isMoxie.checked == true && isMoxie.disabled == false){
			MoxieMulti = 2;
		}
		if (Attack.target == 2){
			Defence = 0;
			DamageOutput.style.color ="green";
			DefenceMulti = 1;
			Crit = 1;
		}else{
			DamageOutput.style.color ="red";
		}
		
		RawDamage = (ChosenAttackStat/2 + Power/2 - Defence/4)
		if (RawDamage < 1){
			RawDamage = 1;	
		}
		Damage = (RawDamage*RandMulti*DefenceMulti*ElementalResistance*Crit*MoxieMulti)*Hit_amount
		Damage = Math.round(Damage) 
		DamageOutput.innerHTML = Damage;
		console.log(Damage)
		console.log(DefenderEV_Div)
		console.log(Attitudes[DefenderEV_Div.value])
		DetermineHitAmount(Damage, parseInt(DefenderHP.value)+parseInt(Attitudes[DefenderEV.value].boost[0]))
}

function DetermineHitAmount(Damage, DefenderHealth){
	console.log(Damage)
	console.log(DefenderHealth)
	let Amount = Math.ceil(DefenderHealth / Damage)
	HitsDiv.innerHTML = Amount;
}

function SetAttackerData(HP_IV, STR_IV, SPR_IV, DEF_IV, SPD_IV, STR_Gym, SPR_Gym, DEF_Gym, SPD_Gym){
	var AttackerNumber = Attacker.value;
		
	AttackerImg.src = 'Content/Graphics/Yo kai Medals/'+yokais[AttackerNumber].image
	let [BHP, BSTR, BSPR, BDEF, BSPD] = CalculateStats(yokais[AttackerNumber], HP_IV, STR_IV, SPR_IV, DEF_IV, SPD_IV, parseInt(AttackerLVL.value), STR_Gym, SPR_Gym, DEF_Gym, SPD_Gym)
	
	AttackerHP.value = Math.round(BHP)
	AttackerSTR.value = Math.round(BSTR);
	AttackerSPR.value = Math.round(BSPR);
	AttackerDEF.value = Math.round(BDEF);
	AttackerSPD.value = Math.round(BSPD);
}

function setDefenderData(HP_IV, STR_IV, SPR_IV, DEF_IV, SPD_IV, STR_Gym, SPR_Gym, DEF_Gym, SPD_Gym){
	var DefenderNumber = Defender.value
		
	DefenderImg.src = 'Content/Graphics/Yo kai Medals/'+yokais[DefenderNumber].image
	let [BHP, BSTR, BSPR, BDEF, BSPD] = CalculateStats(yokais[DefenderNumber], HP_IV, STR_IV, SPR_IV, DEF_IV, SPD_IV, parseInt(DefenderLVL.value), STR_Gym, SPR_Gym, DEF_Gym, SPD_Gym)
		
	DefenderHP.value = Math.round(BHP)	
	DefenderSTR.value = Math.round(BSTR);
	DefenderSPR.value = Math.round(BSPR);
	DefenderDEF.value = Math.round(BDEF);
	DefenderSPD.value = Math.round(BSPD);
}

function CheckIV(){
	if ((parseInt(AttackerHP_IV) + parseInt(AttackerSTR_IV) + parseInt(AttackerSPR_IV) + parseInt(AttackerDEF_IV) + parseInt(AttackerSPD_IV)) != 40){
		AttackerHP_IV_Input.style = "color: red";
		AttackerSTR_IV_Input.style = "color: red";
		AttackerSPR_IV_Input.style = "color: red";
		AttackerDEF_IV_Input.style = "color: red";
		AttackerSPD_IV_Input.style = "color: red";
	}
	else{
		AttackerHP_IV_Input.style = "color: black";
		AttackerSTR_IV_Input.style = "color: black";
		AttackerSPR_IV_Input.style = "color: black";
		AttackerDEF_IV_Input.style = "color: black";
		AttackerSPD_IV_Input.style = "color: black";
	}
	SetAttackerData(AttackerHP_IV,AttackerSTR_IV,AttackerSPR_IV, AttackerDEF_IV, AttackerSPD_IV, AttackerSTR_Gym, AttackerSPR_Gym, AttackerDEF_Gym, AttackerSPD_Gym)
	if ((parseInt(DefenderHP_IV) + parseInt(DefenderSTR_IV) + parseInt(DefenderSPR_IV) + parseInt(DefenderDEF_IV) + parseInt(DefenderSPD_IV)) != 40){
		DefenderHP_IV_Input.style = "color: red";
		DefenderSTR_IV_Input.style = "color: red";
		DefenderSPR_IV_Input.style = "color: red";
		DefenderDEF_IV_Input.style = "color: red";
		DefenderSPD_IV_Input.style = "color: red";
	}
	else{
		DefenderHP_IV_Input.style = "color: black";
		DefenderSTR_IV_Input.style = "color: black";
		DefenderSPR_IV_Input.style = "color: black";
		DefenderDEF_IV_Input.style = "color: black";
		DefenderSPD_IV_Input.style = "color: black";
	}
	setDefenderData(DefenderHP_IV,DefenderSTR_IV,DefenderSPR_IV,DefenderDEF_IV,DefenderSPD_IV, DefenderSTR_Gym, DefenderSPR_Gym, DefenderDEF_Gym, DefenderSPD_Gym)
}

function CheckGymStat(){
	if (parseInt(DefenderSTR_Gym_Input.value) + parseInt(DefenderSPR_Gym_Input.value) + parseInt(DefenderDEF_Gym_Input.value) + parseInt(DefenderSPD_Gym_Input.value) > 5){
		DefenderSTR_Gym_Input.style.color = "red";
		DefenderSPR_Gym_Input.style.color = "red";
		DefenderDEF_Gym_Input.style.color = "red";
		DefenderSPD_Gym_Input.style.color = "red";
	}else{
		DefenderSTR_Gym_Input.style.color = "black";
		DefenderSPR_Gym_Input.style.color = "black";
		DefenderDEF_Gym_Input.style.color = "black";
		DefenderSPD_Gym_Input.style.color = "black";
	}
	setDefenderData(DefenderHP_IV,DefenderSTR_IV,DefenderSPR_IV,DefenderDEF_IV,DefenderSPD_IV, DefenderSTR_Gym, DefenderSPR_Gym, DefenderDEF_Gym, DefenderSPD_Gym)
	if (parseInt(AttackerSTR_Gym_Input.value) + parseInt(AttackerSPR_Gym_Input.value) + parseInt(AttackerDEF_Gym_Input.value) + parseInt(AttackerSPD_Gym_Input.value) > 5){
		AttackerSTR_Gym_Input.style.color = "red";
		AttackerSPR_Gym_Input.style.color = "red";
		AttackerDEF_Gym_Input.style.color = "red";
		AttackerSPD_Gym_Input.style.color = "red";
	}else{
		AttackerSTR_Gym_Input.style.color = "black";
		AttackerSPR_Gym_Input.style.color = "black";
		AttackerDEF_Gym_Input.style.color = "black";
		AttackerSPD_Gym_Input.style.color = "black";
	}
	SetAttackerData(AttackerHP_IV,AttackerSTR_IV,AttackerSPR_IV, AttackerDEF_IV, AttackerSPD_IV, AttackerSTR_Gym, AttackerSPR_Gym, AttackerDEF_Gym, AttackerSPD_Gym)
}

	if (Defender){
		
		for (i = 0; i < yokais.length; i++){
			const option = `
				<option value="${i}">${yokais[i].name}</option>
			`
			Defender.innerHTML += option;
			Attacker.innerHTML += option;
		}
		for (i = 0; i < Attitudes.length; i++){
			const option = `
			<option value="${i}">${Attitudes[i].name}</option>
			`
			DefenderEV.innerHTML += option;
			AttackerEV.innerHTML += option;
		}
		
	//(STRorSPR/2 + BP/2)*0.9or1.1*ElementalWeaknessResistance*SkillMultiplier*Guard 
	
	Attacker.addEventListener('change', function(event) { 
	SetAttackerData(AttackerHP_IV,AttackerSTR_IV,AttackerSPR_IV, AttackerDEF_IV, AttackerSPD_IV, AttackerSTR_Gym, AttackerSPR_Gym, AttackerDEF_Gym, AttackerSPD_Gym)
	})
	
	Defender.addEventListener('change', function(event) {
	setDefenderData(DefenderHP_IV,DefenderSTR_IV,DefenderSPR_IV,DefenderDEF_IV,DefenderSPD_IV, DefenderSTR_Gym, DefenderSPR_Gym, DefenderDEF_Gym, DefenderSPD_Gym)
	})
	
	DefenderLVL.addEventListener('input', function(event){
	setDefenderData(DefenderHP_IV,DefenderSTR_IV,DefenderSPR_IV,DefenderDEF_IV,DefenderSPD_IV, DefenderSTR_Gym, DefenderSPR_Gym, DefenderDEF_Gym, DefenderSPD_Gym)
	})
	
	AttackerLVL.addEventListener('input', function(event){
	SetAttackerData(AttackerHP_IV,AttackerSTR_IV,AttackerSPR_IV, AttackerDEF_IV, AttackerSPD_IV, AttackerSTR_Gym, AttackerSPR_Gym, AttackerDEF_Gym, AttackerSPD_Gym)
	})
	
	DefenderHP_IV_Input.addEventListener('input', function(event){
		DefenderHP_IV = DefenderHP_IV_Input.value;
		CheckIV()
	})
	DefenderSTR_IV_Input.addEventListener('input', function(event){
		DefenderSTR_IV = DefenderSTR_IV_Input.value;
		CheckIV()
	})
	DefenderSPR_IV_Input.addEventListener('input', function(event){
		DefenderSPR_IV = DefenderSPR_IV_Input.value;
		CheckIV()
	})
	DefenderDEF_IV_Input.addEventListener('input', function(event){
		DefenderDEF_IV = DefenderDEF_IV_Input.value;
		CheckIV()
	})
	DefenderSPD_IV_Input.addEventListener('input', function(event){
		DefenderSPD_IV = DefenderSPD_IV_Input.value;
		CheckIV()
	})
	
	AttackerHP_IV_Input.addEventListener('input', function(event){
		AttackerHP_IV = AttackerHP_IV_Input.value;
		CheckIV()
	})
	AttackerSTR_IV_Input.addEventListener('input', function(event){
		AttackerSTR_IV = AttackerSTR_IV_Input.value;
		CheckIV()
	})
	AttackerSPR_IV_Input.addEventListener('input', function(event){
		AttackerSPR_IV = AttackerSPR_IV_Input.value;
		CheckIV()
	})
	AttackerDEF_IV_Input.addEventListener('input', function(event){
		AttackerDEF_IV = AttackerDEF_IV_Input.value;
		CheckIV()
	})
	AttackerSPD_IV_Input.addEventListener('input', function(event){
		AttackerSPD_IV = AttackerSPD_IV_Input.value;
		CheckIV()
	})
	
	DefenderSTR_Gym_Input.addEventListener('input', function(event){
		DefenderSTR_Gym = DefenderSTR_Gym_Input.value;
		CheckGymStat()
	})
	DefenderSPR_Gym_Input.addEventListener('input', function(event){
		DefenderSPR_Gym = DefenderSPR_Gym_Input.value;
		CheckGymStat()
	})
	DefenderDEF_Gym_Input.addEventListener('input', function(event){
		DefenderDEF_Gym = DefenderDEF_Gym_Input.value;
		CheckGymStat()
	})
	DefenderSPD_Gym_Input.addEventListener('input', function(event){
		DefenderSPD_Gym = DefenderSPD_Gym_Input.value;
		CheckGymStat()
	})
	
	AttackerSTR_Gym_Input.addEventListener('input', function(event){
		AttackerSTR_Gym = AttackerSTR_Gym_Input.value;
		CheckGymStat()
	})
	AttackerSPR_Gym_Input.addEventListener('input', function(event){
		AttackerSPR_Gym = AttackerSPR_Gym_Input.value;
		CheckGymStat()
	})
	AttackerDEF_Gym_Input.addEventListener('input', function(event){
		AttackerDEF_Gym = AttackerDEF_Gym_Input.value;
		CheckGymStat()
	})
	AttackerSPD_Gym_Input.addEventListener('input', function(event){
		AttackerSPD_Gym = AttackerSPD_Gym_Input.value;
		CheckGymStat()
	})
	
	DefenderEV.addEventListener('change', function(event){
		DefenderEV_Div.innerHTML = 'HP Boost:'+Attitudes[DefenderEV.value].boost[0]+' | STR Boost:'+Attitudes[DefenderEV.value].boost[1]+' | SPR Boost:'+Attitudes[DefenderEV.value].boost[2]+' | DEF Boost:'+Attitudes[DefenderEV.value].boost[3]+' | SPD Boost:'+Attitudes[DefenderEV.value].boost[4]
	})
	AttackerEV.addEventListener('change', function(event){
		AttackerEV_Div.innerHTML = 'HP Boost:'+Attitudes[AttackerEV.value].boost[0]+' | STR Boost:'+Attitudes[AttackerEV.value].boost[1]+' | SPR Boost:'+Attitudes[AttackerEV.value].boost[2]+' | DEF Boost:'+Attitudes[AttackerEV.value].boost[3]+' | SPD Boost:'+Attitudes[AttackerEV.value].boost[4]
	})
	AttackerEV_Div.innerHTML = 'HP Boost:'+Attitudes[AttackerEV.value].boost[0]+' | STR Boost:'+Attitudes[AttackerEV.value].boost[1]+' | SPR Boost:'+Attitudes[AttackerEV.value].boost[2]+' | DEF Boost:'+Attitudes[AttackerEV.value].boost[3]+' | SPD Boost:'+Attitudes[AttackerEV.value].boost[4]
	
	DefenderEV_Div.innerHTML = 'HP Boost:'+Attitudes[DefenderEV.value].boost[0]+' | STR Boost:'+Attitudes[DefenderEV.value].boost[1]+' | SPR Boost:'+Attitudes[DefenderEV.value].boost[2]+' | DEF Boost:'+Attitudes[DefenderEV.value].boost[3]+' | SPD Boost:'+Attitudes[DefenderEV.value].boost[4]

	AttackType.addEventListener('change', function(event){
		if (AttackType.value == "3"){
			isMoxie.disabled = false;
		}
		else{
			isMoxie.disabled = true;
		}
	})
	
	var AttackerNumber = Attacker.value;
		
AttackerImg.src = 'Content/Graphics/Yo kai Medals/'+yokais[AttackerNumber].image;
		
var DefenderNumber = Defender.value;
		
DefenderImg.src = 'Content/Graphics/Yo kai Medals/'+yokais[DefenderNumber].image;
	
	SetAttackerData(8, 8, 8, 8, 8, 60, 0, 0, 0, 0)
	
	setDefenderData(8, 8, 8, 8, 8, 60, 0, 0, 0, 0)
	
	CalcButton.addEventListener("click", () =>{
		
		if (AttackType.value == "1"){
		getAttack(GetMove(yokais[Attacker.value]))
	}
	else if (AttackType.value == "2"){
		getAttack(GetTechnique(yokais[Attacker.value]))
	}
	else if(AttackType.value == "3"){
		getAttack(GetSoultimate(yokais[Attacker.value]))
	}
	});

}

